package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.theme.MyApplicationTheme
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAds.UnityAdsShowCompletionState
import com.unity3d.ads.UnityAdsShowOptions
import com.unity3d.ads.UnityAdsLoadOptions
import com.unity3d.ads.BannerAd
import com.unity3d.ads.BannerConfiguration
import com.unity3d.ads.LoadListener
import com.unity3d.ads.BannerShowListener
import com.unity3d.ads.BannerSize
import com.unity3d.ads.UnityAdsError

private const val UNITY_GAME_ID = "800454412"
private const val UNITY_TEST_MODE = true // Change to false only after successful test-ad checks.
private const val PLACEMENT_BANNER = "BP_Banner_Android"
private const val PLACEMENT_INTERSTITIAL = "BP_Interstitial_Android"
private const val PLACEMENT_REWARDED = "BP_Rewarded_Android"
private const val ADS_TAG = "CoinJumpUnityAds"

class MainActivity : ComponentActivity() {
  private lateinit var adsController: UnityAdsController

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    adsController = UnityAdsController(this)
    adsController.initialize()
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
    )
    setContent {
      MyApplicationTheme {
        CoinJumpGameScreen(onExitApp = { finish() }, adsController = adsController)
      }
    }
  }

  override fun onDestroy() {
    if (::adsController.isInitialized) adsController.destroy()
    super.onDestroy()
  }
}

private class UnityAdsController(private val activity: ComponentActivity) {
  private var initialized = false
  private var interstitialReady = false
  private var rewardedReady = false
  private var webView: WebView? = null
  private var bannerHost: FrameLayout? = null
  private var bannerAd: BannerAd? = null

  fun initialize() {
    UnityAds.initialize(activity, UNITY_GAME_ID, UNITY_TEST_MODE, object : IUnityAdsInitializationListener {
      override fun onInitializationComplete() {
        initialized = true
        preloadAds()
        loadBanner()
      }
      override fun onInitializationFailed(error: UnityAds.UnityAdsInitializationError, message: String) {
        Log.e(ADS_TAG, "Unity Ads initialization failed: $message")
      }
    })
  }

  fun attachWebView(view: WebView) { webView = view }

  fun attachBannerHost(host: FrameLayout) {
    bannerHost = host
    bannerAd?.view?.let { addBannerToHost(it) }
    if (initialized && bannerAd == null) loadBanner()
  }

  private fun preloadAds() {
    if (!initialized) return
    UnityAds.load(PLACEMENT_INTERSTITIAL, UnityAdsLoadOptions(), object : IUnityAdsLoadListener {
      override fun onUnityAdsAdLoaded(placementId: String) { interstitialReady = true }
      override fun onUnityAdsFailedToLoad(placementId: String, error: UnityAds.UnityAdsLoadError, message: String) {
        interstitialReady = false
        Log.w(ADS_TAG, "Interstitial load failed: $message")
      }
    })
    UnityAds.load(PLACEMENT_REWARDED, UnityAdsLoadOptions(), object : IUnityAdsLoadListener {
      override fun onUnityAdsAdLoaded(placementId: String) { rewardedReady = true }
      override fun onUnityAdsFailedToLoad(placementId: String, error: UnityAds.UnityAdsLoadError, message: String) {
        rewardedReady = false
        Log.w(ADS_TAG, "Rewarded load failed: $message")
      }
    })
  }

  fun showInterstitial() {
    activity.runOnUiThread {
      if (!initialized || !interstitialReady) { preloadAds(); return@runOnUiThread }
      interstitialReady = false
      UnityAds.show(activity, PLACEMENT_INTERSTITIAL, UnityAdsShowOptions(), object : IUnityAdsShowListener {
        override fun onUnityAdsShowFailure(placementId: String, error: UnityAds.UnityAdsShowError, message: String) {
          Log.w(ADS_TAG, "Interstitial show failed: $message")
          preloadAds()
        }
        override fun onUnityAdsShowStart(placementId: String) {}
        override fun onUnityAdsShowClick(placementId: String) {}
        override fun onUnityAdsShowComplete(placementId: String, state: UnityAdsShowCompletionState) { preloadAds() }
      })
    }
  }

  fun showRewarded() {
    activity.runOnUiThread {
      if (!initialized || !rewardedReady) {
        webView?.evaluateJavascript("window.CoinJumpApp && window.CoinJumpApp.onRewardAdUnavailable && window.CoinJumpApp.onRewardAdUnavailable();", null)
        preloadAds()
        return@runOnUiThread
      }
      rewardedReady = false
      UnityAds.show(activity, PLACEMENT_REWARDED, UnityAdsShowOptions(), object : IUnityAdsShowListener {
        override fun onUnityAdsShowFailure(placementId: String, error: UnityAds.UnityAdsShowError, message: String) {
          Log.w(ADS_TAG, "Rewarded show failed: $message")
          webView?.evaluateJavascript("window.CoinJumpApp && window.CoinJumpApp.onRewardAdUnavailable && window.CoinJumpApp.onRewardAdUnavailable();", null)
          preloadAds()
        }
        override fun onUnityAdsShowStart(placementId: String) {}
        override fun onUnityAdsShowClick(placementId: String) {}
        override fun onUnityAdsShowComplete(placementId: String, state: UnityAdsShowCompletionState) {
          if (state == UnityAdsShowCompletionState.COMPLETED) {
            webView?.evaluateJavascript("window.CoinJumpApp && window.CoinJumpApp.grantExtraLife && window.CoinJumpApp.grantExtraLife();", null)
          } else {
            webView?.evaluateJavascript("window.CoinJumpApp && window.CoinJumpApp.onRewardAdUnavailable && window.CoinJumpApp.onRewardAdUnavailable();", null)
          }
          preloadAds()
        }
      })
    }
  }

  private fun loadBanner() {
    if (!initialized || bannerAd != null) return
    val showListener = object : BannerShowListener {
      override fun onImpression(ad: BannerAd) { Log.d(ADS_TAG, "Banner impression") }
      override fun onClicked(ad: BannerAd) { Log.d(ADS_TAG, "Banner clicked") }
      override fun onFailedToShow(ad: BannerAd, error: UnityAdsError) {
        Log.w(ADS_TAG, "Banner failed to show: ${error.message}")
      }
    }
    val config = BannerConfiguration.Builder(PLACEMENT_BANNER, BannerSize(320, 50), showListener).build()
    BannerAd.load(config, object : LoadListener<BannerAd> {
      override fun onAdLoaded(loadedAd: BannerAd?, error: UnityAdsError?) {
        if (loadedAd != null) {
          bannerAd = loadedAd
          loadedAd.view?.let { addBannerToHost(it) }
        } else {
          Log.w(ADS_TAG, "Banner load failed: ${error?.message}")
        }
      }
    })
  }

  private fun addBannerToHost(view: View) {
    val host = bannerHost ?: return
    host.post {
      (view.parent as? ViewGroup)?.removeView(view)
      host.removeAllViews()
      host.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }
  }

  fun destroy() {
    bannerAd = null
    webView = null
    bannerHost = null
  }
}

private class AndroidAdsBridge(private val ads: UnityAdsController) {
  @JavascriptInterface fun showInterstitial() { ads.showInterstitial() }
  @JavascriptInterface fun showRewarded() { ads.showRewarded() }
}

private class AndroidStorageBridge(context: Context) {
  private val prefs = context.getSharedPreferences("coin_jump_adventure_prefs", Context.MODE_PRIVATE)
  @JavascriptInterface fun getItem(key: String): String? = prefs.getString(key, null)
  @JavascriptInterface fun setItem(key: String, value: String) { prefs.edit().putString(key, value).apply() }
  @JavascriptInterface fun removeItem(key: String) { prefs.edit().remove(key).apply() }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun CoinJumpGameScreen(onExitApp: () -> Unit, adsController: UnityAdsController) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val density = LocalDensity.current
  val layoutDirection = LocalLayoutDirection.current
  val safeInsets = WindowInsets.safeDrawing
  val topDp = with(density) { safeInsets.getTop(density).toDp().value }
  val bottomDp = with(density) { safeInsets.getBottom(density).toDp().value }
  val leftDp = with(density) { safeInsets.getLeft(density, layoutDirection).toDp().value }
  val rightDp = with(density) { safeInsets.getRight(density, layoutDirection).toDp().value }
  var pageLoaded by remember { mutableStateOf(false) }
  val bannerHost = remember { FrameLayout(context) }

  val webView = remember {
    WebView(context).apply {
      layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
      setBackgroundColor(AndroidColor.rgb(15, 42, 32))
      setLayerType(View.LAYER_TYPE_HARDWARE, null)
      isFocusable = true
      isFocusableInTouchMode = true
      overScrollMode = View.OVER_SCROLL_NEVER
      settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        databaseEnabled = true
        allowFileAccess = true
        @Suppress("DEPRECATION")
        allowFileAccessFromFileURLs = true
        mediaPlaybackRequiresUserGesture = false
        useWideViewPort = true
        loadWithOverviewMode = true
        setSupportZoom(false)
        builtInZoomControls = false
        displayZoomControls = false
        cacheMode = WebSettings.LOAD_DEFAULT
      }
      addJavascriptInterface(AndroidStorageBridge(context.applicationContext), "AndroidStorage")
      addJavascriptInterface(AndroidAdsBridge(adsController), "AndroidAds")
      adsController.attachWebView(this)
      webChromeClient = WebChromeClient()
      webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView?, url: String?) { super.onPageFinished(view, url); pageLoaded = true }
      }
      loadUrl("file:///android_asset/game/index.html")
    }
  }

  LaunchedEffect(pageLoaded, topDp, bottomDp, leftDp, rightDp) {
    if (pageLoaded) {
      val js = """(function(){var r=document.documentElement.style;r.setProperty('--safe-top','${topDp}px');r.setProperty('--safe-bottom','${bottomDp}px');r.setProperty('--safe-left','${leftDp}px');r.setProperty('--safe-right','${rightDp}px');})();"""
      webView.evaluateJavascript(js, null)
    }
  }

  DisposableEffect(lifecycleOwner, webView) {
    val observer = LifecycleEventObserver { _, event ->
      when (event) {
        Lifecycle.Event.ON_PAUSE -> { webView.evaluateJavascript("window.CoinJumpApp && window.CoinJumpApp.onAppPause && window.CoinJumpApp.onAppPause();", null); webView.onPause() }
        Lifecycle.Event.ON_RESUME -> { webView.onResume(); webView.evaluateJavascript("window.CoinJumpApp && window.CoinJumpApp.onAppResume && window.CoinJumpApp.onAppResume();", null) }
        Lifecycle.Event.ON_DESTROY -> webView.destroy()
        else -> Unit
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  BackHandler {
    webView.evaluateJavascript("(function(){ return window.CoinJumpApp && window.CoinJumpApp.handleBack ? window.CoinJumpApp.handleBack() : 'exit'; })();") { result ->
      if (result?.contains("exit") == true) onExitApp()
    }
  }

  Column(modifier = Modifier.fillMaxSize().background(Color(0xFF0F2A20))) {
    Box(modifier = Modifier.weight(1f)) { AndroidView(factory = { webView }, modifier = Modifier.fillMaxSize()) }
    AndroidView(factory = { bannerHost.also { adsController.attachBannerHost(it) } }, modifier = Modifier.height(50.dp).fillMaxWidth())
  }
}
