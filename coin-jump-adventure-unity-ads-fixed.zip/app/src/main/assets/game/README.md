# Coin Jump Adventure

An original, colorful 2D side-scrolling platform adventure game built with **HTML5 Canvas**, **CSS3**, **Vanilla JavaScript**, and the **Web Audio API**, packaged as an offline-ready Android app with Jetpack Compose `WebView` integration.

## Source Code Organization

- `index.html` — Game container, Canvas, HUD, touch controls, menus, level select, settings, and result screens.
- `css/style.css` — Responsive mobile-first & desktop layout, safe-area inset handling, and frosted glass UI overlays.
- `js/storage.js` — Local persistence for best scores, stars, coins, and audio/control settings (`AndroidStorage` SharedPreferences bridge + `localStorage` fallback).
- `js/audio.js` — Original Web Audio API synthesizer & mixer (`DynamicsCompressor`, speaker-friendly EQ, separate Music & SFX gain buses, mute/unmute, procedural adventure music per world, and distinct SFX for coin, jump, land, footsteps, stomp, hurt, power-ups, checkpoint, level complete, and game over).
- `js/levels.js` — 3 complete playable worlds with increasing difficulty:
  1. **Whispering Forest** (Easy)
  2. **Highwind Peaks** (Medium)
  3. **Crystal Treasure Cave** (Hard)
- `js/entities.js` — Player state, world entity factories, physics constants, particles, and floating score popups.
- `js/renderer.js` — Parallax 2D Canvas backgrounds, Pip the White Rabbit animations (idle, run, jump, fall, land, blink, scarf wave, shield & speed auras), spinning coins, power-ups, enemies, hazards, and checkpoints.
- `js/game.js` — Fixed-aspect responsive viewport scaling, delta-time game loop, coyote time, jump buffering, moving platforms, collision detection, and win/loss flow.
- `js/main.js` — Multi-touch pointer controls, keyboard bindings, Start screen mascot preview, settings UI, and Android back/lifecycle hooks.

## Controls

- **Mobile / Touch**: Use the bottom-left **◀ / ▶** buttons to run and the bottom-right **▲ JUMP** button to jump.
- **Desktop Keyboard**:
  - `Arrow Left / Right` or `A / D`: Run
  - `Space` / `Arrow Up` / `W`: Jump (hold slightly longer for higher jumps)
  - `P` or `Escape`: Pause / Resume
  - `R`: Restart current level

## Running in a Desktop or Mobile Browser

Serve `app/src/main/assets/game/` with any static HTTP server (or open `index.html` directly):

```sh
cd app/src/main/assets/game
python3 -m http.server 8080
```

Then visit `http://localhost:8080`.
