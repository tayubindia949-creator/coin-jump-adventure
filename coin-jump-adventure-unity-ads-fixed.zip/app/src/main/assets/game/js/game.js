/**
 * Core gameplay loop, physics, collision detection, camera, and state management
 * for Coin Jump Adventure.
 */
window.CoinJumpGame = (function () {
  const E = window.GameEntities;

  function createEngine(canvas, callbacks) {
    const ctx = canvas.getContext("2d");

    const input = {
      left: false,
      right: false,
      jumpHeld: false,
      jumpJustPressed: false
    };

    const state = {
      mode: "menu", // "menu" | "playing" | "paused" | "complete" | "gameover"
      levelId: 1,
      level: window.GameLevels.getLevel(1),
      world: null,
      player: null,
      respawn: { x: 80, y: 380 },
      lives: 3,
      coinsCollected: 0,
      totalCoins: 0,
      score: 0,
      elapsed: 0,
      time: 0,
      camX: 0,
      camY: 0,
      shake: 0,
      rafId: null,
      lastFrame: 0,
      vw: 800,
      vh: 540,
      scale: 1
    };

    function updateViewportSize() {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const cssW = canvas.clientWidth || window.innerWidth;
      const cssH = canvas.clientHeight || window.innerHeight;
      canvas.width = Math.max(1, Math.floor(cssW * dpr));
      canvas.height = Math.max(1, Math.floor(cssH * dpr));

      const aspect = cssW / Math.max(1, cssH);
      // Ensure generous horizontal look-ahead in both portrait & landscape mobile screens
      if (aspect >= 1.15) {
        state.vh = 540;
        state.vw = Math.max(620, 540 * aspect);
      } else {
        state.vw = 580;
        state.vh = Math.max(540, 580 / Math.max(0.45, aspect));
      }
      state.scale = canvas.width / state.vw;
    }

    function loadLevel(levelId) {
      const lvl = window.GameLevels.getLevel(levelId);
      state.levelId = lvl.id;
      state.level = lvl;
      state.world = E.buildWorld(lvl);
      state.respawn = { x: lvl.spawn.x, y: lvl.spawn.y };
      state.player = E.createPlayer(state.respawn);
      state.lives = 3;
      state.coinsCollected = 0;
      state.totalCoins = state.world.coins.length;
      state.score = 0;
      state.elapsed = 0;
      state.shake = 0;
      state.camX = 0;
      state.camY = Math.max(0, 540 - state.vh) * -0.45;
      callbacks.onHudUpdate(getHudSnapshot());
    }

    function startLevel(levelId) {
      loadLevel(levelId);
      state.mode = "playing";
      window.SoundEngine.unlock();
      window.SoundEngine.startMusic(state.levelId);
      callbacks.onModeChange("playing");
      callbacks.onHudUpdate(getHudSnapshot());
      callbacks.onToast(`${state.level.name} — Collect coins & reach the portal!`);
    }

    function pause() {
      if (state.mode !== "playing") return;
      state.mode = "paused";
      window.SoundEngine.pauseMusic();
      callbacks.onModeChange("paused");
    }

    function resume() {
      if (state.mode !== "paused") return;
      state.mode = "playing";
      state.lastFrame = performance.now();
      window.SoundEngine.resumeMusic();
      callbacks.onModeChange("playing");
    }

    function restart() {
      startLevel(state.levelId);
    }

    function grantExtraLife() {
      if (state.mode !== "gameover" || !state.player) return false;
      state.lives = 1;
      state.player.x = state.respawn.x;
      state.player.y = state.respawn.y;
      state.player.vx = 0;
      state.player.vy = 0;
      state.player.invulnTimer = 2.2;
      state.player.grounded = false;
      state.mode = "playing";
      state.lastFrame = performance.now();
      window.SoundEngine.unlock();
      window.SoundEngine.resumeMusic();
      callbacks.onModeChange("playing");
      callbacks.onHudUpdate(getHudSnapshot());
      callbacks.onToast("Extra life unlocked! Keep going!");
      return true;
    }

    function stopToMenu() {
      state.mode = "menu";
      window.SoundEngine.stopMusic();
      callbacks.onModeChange("menu");
    }

    function getHudSnapshot() {
      return {
        levelId: state.levelId,
        levelName: state.level.name,
        lives: state.lives,
        coins: state.coinsCollected,
        totalCoins: state.totalCoins,
        score: state.score,
        speedTimer: state.player ? state.player.speedTimer : 0,
        shieldTimer: state.player ? state.player.shieldTimer : 0,
        magnetTimer: state.player ? state.player.magnetTimer : 0
      };
    }

    function aabbOverlap(ax, ay, aw, ah, bx, by, bw, bh) {
      return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
    }

    function hurtPlayer(fromPit) {
      const p = state.player;
      if (!fromPit && p.invulnTimer > 0) return;

      if (!fromPit && p.shieldTimer > 0) {
        p.shieldTimer = 0;
        p.invulnTimer = 1.4;
        p.vy = -340;
        state.shake = 0.45;
        E.spawnSparkles(state.world, p.x + p.w / 2, p.y + p.h / 2, "#67e8f9", 14);
        E.spawnFloatingText(state.world, p.x + p.w / 2, p.y - 8, "SHIELD SAVED!", "#67e8f9");
        window.SoundEngine.playHurt(true);
        callbacks.onHudUpdate(getHudSnapshot());
        return;
      }

      state.lives -= 1;
      state.shake = 0.7;
      window.SoundEngine.playHurt(false);
      E.spawnParticles(state.world, p.x + p.w / 2, p.y + p.h / 2, "#fb7185", 14, 220, 0.8);

      if (state.lives <= 0) {
        state.lives = 0;
        state.mode = "gameover";
        window.SoundEngine.stopMusic();
        window.SoundEngine.playGameOver();
        callbacks.onHudUpdate(getHudSnapshot());
        callbacks.onGameOver({
          coins: state.coinsCollected,
          score: state.score
        });
        return;
      }

      // Respawn at latest checkpoint or level start
      p.x = state.respawn.x;
      p.y = state.respawn.y;
      p.vx = 0;
      p.vy = 0;
      p.invulnTimer = 1.8;
      p.grounded = false;
      callbacks.onHudUpdate(getHudSnapshot());
      callbacks.onToast("Respawned at Checkpoint!");
    }

    function completeLevel() {
      state.mode = "complete";
      window.SoundEngine.stopMusic();
      window.SoundEngine.playLevelComplete();

      const coinRatio = state.totalCoins > 0 ? state.coinsCollected / state.totalCoins : 1;
      let stars = 1;
      if (coinRatio >= 0.55) stars = 2;
      if (coinRatio >= 0.8 && state.lives >= 2) stars = 3;

      const coinBonus = state.coinsCollected * 15 + stars * 100;
      const timeBonus = Math.max(0, Math.round((150 - state.elapsed) * 4)) + state.lives * 150;
      const finalScore = state.score + coinBonus + timeBonus;
      state.score = finalScore;

      const saveRes = window.GameStorage.recordLevelResult(
        state.levelId,
        finalScore,
        state.coinsCollected,
        stars
      );

      callbacks.onHudUpdate(getHudSnapshot());
      callbacks.onLevelComplete({
        levelId: state.levelId,
        levelName: state.level.name,
        stars,
        coins: state.coinsCollected,
        totalCoins: state.totalCoins,
        coinBonus,
        timeBonus,
        totalScore: finalScore,
        isNewBest: saveRes.isNewBest,
        hasNextLevel: state.levelId < 3
      });
    }

    function updateWorld(dt) {
      const world = state.world;
      const p = state.player;
      state.elapsed += dt;
      if (state.shake > 0) state.shake = Math.max(0, state.shake - dt * 2.4);

      // Update moving platforms
      world.movingPlatforms.forEach((mp) => {
        const prevX = mp.x;
        const prevY = mp.y;
        mp.phase += dt * mp.speed;
        const offset = Math.sin(mp.phase) * mp.range;
        if (mp.axis === "x") {
          mp.x = mp.baseX + offset;
        } else {
          mp.y = mp.baseY + offset;
        }
        mp.dx = mp.x - prevX;
        mp.dy = mp.y - prevY;
      });

      // Carry player if standing on moving platform
      if (p.grounded && p.onPlatform) {
        p.x += p.onPlatform.dx || 0;
        p.y += p.onPlatform.dy || 0;
      }

      // Timers
      if (p.invulnTimer > 0) p.invulnTimer = Math.max(0, p.invulnTimer - dt);
      if (p.speedTimer > 0) p.speedTimer = Math.max(0, p.speedTimer - dt);
      if (p.shieldTimer > 0) p.shieldTimer = Math.max(0, p.shieldTimer - dt);
      if (p.magnetTimer > 0) p.magnetTimer = Math.max(0, p.magnetTimer - dt);

      // Blink animation
      p.blinkTimer -= dt;
      if (p.blinkTimer <= 0) {
        if (p.isBlinking) {
          p.isBlinking = false;
          p.blinkTimer = 2.2 + Math.random() * 2.5;
        } else {
          p.isBlinking = true;
          p.blinkTimer = 0.12;
        }
      }

      // Horizontal movement
      const moveDir = (input.right ? 1 : 0) - (input.left ? 1 : 0);
      const maxSpeed = p.speedTimer > 0 ? E.BOOST_SPEED : E.BASE_SPEED;
      const accel = p.grounded ? 2100 : 1450;
      const friction = p.grounded ? 1900 : 600;

      if (moveDir !== 0) {
        p.facing = moveDir;
        p.vx += moveDir * accel * dt;
        if (Math.abs(p.vx) > maxSpeed) {
          p.vx = moveDir * maxSpeed;
        }
      } else {
        if (Math.abs(p.vx) <= friction * dt) {
          p.vx = 0;
        } else {
          p.vx -= Math.sign(p.vx) * friction * dt;
        }
      }

      // Coyote time & jump buffer
      if (p.grounded) {
        p.coyoteTimer = 0.11;
      } else {
        p.coyoteTimer = Math.max(0, p.coyoteTimer - dt);
      }

      if (input.jumpJustPressed) {
        p.jumpBuffer = 0.13;
        input.jumpJustPressed = false;
      } else {
        p.jumpBuffer = Math.max(0, p.jumpBuffer - dt);
      }

      if (p.jumpBuffer > 0 && p.coyoteTimer > 0) {
        p.vy = E.JUMP_VEL * (p.speedTimer > 0 ? 1.04 : 1);
        p.grounded = false;
        p.onPlatform = null;
        p.coyoteTimer = 0;
        p.jumpBuffer = 0;
        p.squashX = 0.8;
        p.squashY = 1.24;
        E.spawnParticles(world, p.x + p.w / 2, p.y + p.h, "#e2e8f0", 5, 110, 0.35);
        window.SoundEngine.playJump(false);
      }

      // Variable jump height when jump button released early
      if (!input.jumpHeld && p.vy < -220) {
        p.vy += E.GRAVITY * 1.45 * dt;
      }

      // Gravity
      p.vy = Math.min(980, p.vy + E.GRAVITY * dt);

      const allPlats = world.platforms.concat(world.movingPlatforms);

      // Move X & resolve collisions
      p.x += p.vx * dt;
      if (p.x < 0) {
        p.x = 0;
        p.vx = 0;
      }
      if (p.x + p.w > state.level.width) {
        p.x = state.level.width - p.w;
        p.vx = 0;
      }

      for (let i = 0; i < allPlats.length; i++) {
        const pl = allPlats[i];
        if (aabbOverlap(p.x, p.y, p.w, p.h, pl.x, pl.y, pl.w, pl.h)) {
          if (p.vx > 0) {
            p.x = pl.x - p.w;
            p.vx = 0;
          } else if (p.vx < 0) {
            p.x = pl.x + pl.w;
            p.vx = 0;
          }
        }
      }

      // Move Y & resolve collisions
      const wasGrounded = p.grounded;
      const preLandingVy = p.vy;
      p.y += p.vy * dt;
      p.grounded = false;
      p.onPlatform = null;

      for (let i = 0; i < allPlats.length; i++) {
        const pl = allPlats[i];
        if (aabbOverlap(p.x, p.y, p.w, p.h, pl.x, pl.y, pl.w, pl.h)) {
          if (p.vy >= 0) {
            p.y = pl.y - p.h;
            p.vy = 0;
            p.grounded = true;
            p.onPlatform = pl;
          } else if (p.vy < 0) {
            p.y = pl.y + pl.h;
            p.vy = 0;
          }
        }
      }

      // Landing animation & sound
      if (!wasGrounded && p.grounded && preLandingVy > 130) {
        p.squashX = 1.24;
        p.squashY = 0.76;
        const impact = Math.min(1.15, preLandingVy / 650);
        window.SoundEngine.playLand(impact);
        E.spawnParticles(world, p.x + p.w / 2, p.y + p.h, "#cbd5e1", 6, 95, 0.35);
      }

      // Spring back squash-and-stretch
      p.squashX += (1 - p.squashX) * Math.min(1, dt * 14);
      p.squashY += (1 - p.squashY) * Math.min(1, dt * 14);

      // Running stride & footstep SFX
      if (p.grounded && Math.abs(p.vx) > 40) {
        const strideSpeed = (Math.abs(p.vx) / E.BASE_SPEED) * 8.5;
        p.runCycle += dt * strideSpeed;
        p.stepAccum += dt * strideSpeed;
        if (p.stepAccum >= Math.PI) {
          p.stepAccum -= Math.PI;
          window.SoundEngine.playStep();
          E.spawnParticles(world, p.x + p.w / 2, p.y + p.h, "#e2e8f0", 2, 55, 0.25);
        }
      } else {
        p.stepAccum = 0;
      }

      // Speed boost trail
      if (p.speedTimer > 0 && Math.abs(p.vx) > 60) {
        p.trailTimer += dt;
        if (p.trailTimer >= 0.045) {
          p.trailTimer = 0;
          p.trail.push({ x: p.x + p.w / 2, y: p.y + p.h, alpha: 1 });
        }
      }
      for (let i = p.trail.length - 1; i >= 0; i--) {
        p.trail[i].alpha -= dt * 4.5;
        if (p.trail[i].alpha <= 0) p.trail.splice(i, 1);
      }

      // Pit fall check
      if (p.y > 650) {
        hurtPlayer(true);
        return;
      }

      // Spring Pads
      world.springs.forEach((sp) => {
        if (sp.bounceAnim > 0) sp.bounceAnim = Math.max(0, sp.bounceAnim - dt * 4);
        if (aabbOverlap(p.x, p.y, p.w, p.h, sp.x, sp.y - sp.h, sp.w, sp.h)) {
          if (p.vy >= -50) {
            p.vy = E.SPRING_VEL;
            p.grounded = false;
            p.onPlatform = null;
            p.squashX = 0.74;
            p.squashY = 1.32;
            sp.bounceAnim = 1;
            E.spawnSparkles(world, sp.x + sp.w / 2, sp.y - 12, "#fb7185", 8);
            window.SoundEngine.playJump(true);
          }
        }
      });

      // Coins (with magnet pull when bonus active)
      const pcx = p.x + p.w / 2;
      const pcy = p.y + p.h / 2;
      world.coins.forEach((c) => {
        if (c.collected) return;
        const dx = pcx - c.x;
        const dy = pcy - c.y;
        const dist = Math.hypot(dx, dy);

        if (p.magnetTimer > 0 && dist < 175 && dist > 1) {
          c.x += (dx / dist) * 430 * dt;
          c.y += (dy / dist) * 430 * dt;
        }

        if (dist < c.r + 22) {
          c.collected = true;
          const mult = p.magnetTimer > 0 ? 2 : 1;
          const pts = 25 * mult;
          state.coinsCollected += 1;
          state.score += pts;
          E.spawnSparkles(world, c.x, c.y, "#fde047", 8);
          E.spawnFloatingText(world, c.x, c.y - 10, `+${pts}`, "#ffd447");
          window.SoundEngine.playCoin(p.magnetTimer > 0);
        }
      });

      // Power-ups
      world.powerups.forEach((pu) => {
        if (pu.collected) return;
        const dist = Math.hypot(pcx - pu.x, pcy - pu.baseY);
        if (dist < pu.r + 24) {
          pu.collected = true;
          window.SoundEngine.playPowerUp(pu.type);

          if (pu.type === "speed") {
            p.speedTimer = 8.0;
            E.spawnSparkles(world, pu.x, pu.baseY, "#22d3ee", 14);
            E.spawnFloatingText(world, pu.x, pu.baseY - 12, "SPEED BOOST!", "#67e8f9");
            callbacks.onToast("⚡ Speed Boost Activated!");
          } else if (pu.type === "shield") {
            p.shieldTimer = 12.0;
            E.spawnSparkles(world, pu.x, pu.baseY, "#60a5fa", 14);
            E.spawnFloatingText(world, pu.x, pu.baseY - 12, "SHIELD ON!", "#93c5fd");
            callbacks.onToast("🛡️ Crystal Shield Activated!");
          } else {
            p.magnetTimer = 10.0;
            state.coinsCollected += 5;
            state.score += 250;
            E.spawnSparkles(world, pu.x, pu.baseY, "#fbbf24", 18);
            E.spawnFloatingText(world, pu.x, pu.baseY - 12, "+250 COIN MAGNET!", "#fde047");
            callbacks.onToast("🌟 Coin Magnet & 2x Value!");
          }
        }
      });

      // Checkpoints
      world.checkpoints.forEach((cp) => {
        if (cp.activated) return;
        if (Math.abs(pcx - cp.x) < 34 && Math.abs(p.y + p.h - cp.y) < 75) {
          cp.activated = true;
          state.respawn = { x: cp.x - p.w / 2, y: cp.y - p.h - 4 };
          state.score += 100;
          E.spawnSparkles(world, cp.x, cp.y - 52, "#4ade80", 14);
          E.spawnFloatingText(world, cp.x, cp.y - 72, "CHECKPOINT!", "#86efac");
          window.SoundEngine.playCheckpoint();
          callbacks.onToast("🚩 Checkpoint Saved!");
        }
      });

      // Hazards
      for (let i = 0; i < world.hazards.length; i++) {
        const hz = world.hazards[i];
        if (aabbOverlap(p.x + 5, p.y + 6, p.w - 10, p.h - 6, hz.x + 4, hz.y - hz.h + 4, hz.w - 8, hz.h - 4)) {
          hurtPlayer(false);
          return;
        }
      }

      // Enemies
      for (let i = 0; i < world.enemies.length; i++) {
        const e = world.enemies[i];
        if (!e.alive) {
          if (e.squishTimer > 0) e.squishTimer = Math.max(0, e.squishTimer - dt);
          continue;
        }

        if (e.type === "bat") {
          e.phase += dt * e.speed;
          e.y = (e.minY + e.maxY) * 0.5 + Math.sin(e.phase) * ((e.maxY - e.minY) * 0.5);
          e.x += Math.cos(e.phase * 0.65) * e.rangeX * dt;
        } else {
          e.x += e.dir * e.speed * dt;
          if (e.x <= e.minX) {
            e.x = e.minX;
            e.dir = 1;
          } else if (e.x + e.w >= e.maxX) {
            e.x = e.maxX - e.w;
            e.dir = -1;
          }
        }

        const ex = e.x + 3;
        const ey = e.y - e.h + 3;
        const ew = e.w - 6;
        const eh = e.h - 4;
        if (aabbOverlap(p.x + 4, p.y + 4, p.w - 8, p.h - 4, ex, ey, ew, eh)) {
          const isStomp = p.vy > 40 && p.y + p.h - p.vy * dt <= ey + 14;
          if (isStomp && e.type !== "spiky") {
            e.alive = false;
            e.squishTimer = 0.45;
            p.vy = -470;
            state.score += 100;
            E.spawnParticles(world, e.x + e.w / 2, ey + eh / 2, "#c084fc", 10, 170, 0.5);
            E.spawnFloatingText(world, e.x + e.w / 2, ey - 8, "+100", "#e9d5ff");
            window.SoundEngine.playEnemyStomp();
          } else {
            hurtPlayer(false);
            return;
          }
        }
      }

      // Particles & floating texts
      for (let i = world.particles.length - 1; i >= 0; i--) {
        const pt = world.particles[i];
        pt.x += pt.vx * dt;
        pt.y += pt.vy * dt;
        pt.vy += pt.g * dt;
        pt.life -= dt;
        if (pt.life <= 0) world.particles.splice(i, 1);
      }

      for (let i = world.floatingTexts.length - 1; i >= 0; i--) {
        const ft = world.floatingTexts[i];
        ft.y -= 38 * dt;
        ft.life -= dt;
        if (ft.life <= 0) world.floatingTexts.splice(i, 1);
      }

      // Goal portal check
      const goal = state.level.goal;
      if (Math.abs(pcx - goal.x) < 36 && Math.abs(p.y + p.h - goal.y) < 90) {
        completeLevel();
        return;
      }

      // Smooth Camera with look-ahead
      const targetCamX = p.x + p.w / 2 + p.facing * 55 - state.vw * 0.42;
      const maxCamX = Math.max(0, state.level.width - state.vw);
      const clampedX = Math.max(0, Math.min(maxCamX, targetCamX));
      state.camX += (clampedX - state.camX) * Math.min(1, dt * 7.5);

      const targetCamY = Math.min(580 - state.vh, Math.max(-90, p.y - state.vh * 0.56));
      state.camY += (targetCamY - state.camY) * Math.min(1, dt * 6);

      callbacks.onHudUpdate(getHudSnapshot());
    }

    function frame(now) {
      const rawDt = (now - state.lastFrame) / 1000;
      state.lastFrame = now;
      const dt = Math.min(0.045, Math.max(0.001, rawDt));
      state.time += dt;

      if (state.mode === "playing") {
        updateWorld(dt);
      }

      ctx.save();
      ctx.setTransform(state.scale, 0, 0, state.scale, 0, 0);
      if (state.world && state.player) {
        window.GameRenderer.renderWorld(ctx, state, state.vw, state.vh);
      }
      ctx.restore();

      state.rafId = window.requestAnimationFrame(frame);
    }

    function init() {
      updateViewportSize();
      loadLevel(1);
      window.addEventListener("resize", updateViewportSize);
      state.lastFrame = performance.now();
      state.rafId = window.requestAnimationFrame(frame);
    }

    function setInput(action, active) {
      if (action === "left") input.left = active;
      if (action === "right") input.right = active;
      if (action === "jump") {
        if (active && !input.jumpHeld) {
          input.jumpJustPressed = true;
        }
        input.jumpHeld = active;
      }
    }

    return {
      init,
      startLevel,
      pause,
      resume,
      restart,
      grantExtraLife,
      stopToMenu,
      setInput,
      getMode: () => state.mode,
      getLevelId: () => state.levelId
    };
  }

  return { createEngine };
})();
