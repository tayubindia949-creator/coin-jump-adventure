/**
 * Hand-crafted level definitions for Coin Jump Adventure.
 * Virtual ground level is y = 440; pit death threshold is y = 660.
 * Jump reach: ~128px vertical, ~215px horizontal (all normal gaps <= 145px, steps <= 92px).
 */
window.GameLevels = (function () {
  function coinArc(startX, y, count, spacing, arcHeight) {
    const out = [];
    for (let i = 0; i < count; i++) {
      const t = count > 1 ? i / (count - 1) : 0.5;
      const lift = Math.sin(t * Math.PI) * (arcHeight || 0);
      out.push({ x: startX + i * (spacing || 38), y: Math.round(y - lift) });
    }
    return out;
  }

  function coinRow(startX, y, count, spacing) {
    return coinArc(startX, y, count, spacing || 38, 0);
  }

  const LEVELS = [
    // =========================================================================
    // LEVEL 1: WHISPERING GREEN FOREST
    // =========================================================================
    {
      id: 1,
      name: "Whispering Forest",
      subtitle: "Sunny meadows, gentle hops & forest treasures",
      difficulty: "Easy",
      theme: "forest",
      width: 3900,
      spawn: { x: 80, y: 380 },
      goal: { x: 3720, y: 440 },
      platforms: [
        // Starting meadow
        { x: 0, y: 440, w: 620, h: 160, style: "grass" },
        { x: 260, y: 350, w: 140, h: 24, style: "wood" },
        { x: 450, y: 280, w: 130, h: 24, style: "wood" },

        // Gap 1 (110px) -> Berry Hollow
        { x: 730, y: 440, w: 560, h: 160, style: "grass" },
        { x: 860, y: 355, w: 140, h: 24, style: "wood" },
        { x: 1050, y: 290, w: 150, h: 24, style: "wood" },

        // Gap 2 (115px) -> Stream crossing with elevated stepping logs
        { x: 1405, y: 400, w: 145, h: 26, style: "wood" },
        { x: 1645, y: 345, w: 150, h: 26, style: "wood" },

        // Checkpoint 1 Island
        { x: 1890, y: 440, w: 620, h: 160, style: "grass" },
        { x: 2050, y: 340, w: 160, h: 24, style: "wood" },
        { x: 2260, y: 265, w: 160, h: 24, style: "wood" },

        // Canopy section with moving bridge
        { x: 2630, y: 440, w: 320, h: 160, style: "grass" },
        { x: 3240, y: 440, w: 660, h: 160, style: "grass" },
        { x: 3320, y: 345, w: 150, h: 24, style: "wood" },
        { x: 3510, y: 280, w: 130, h: 24, style: "wood" }
      ],
      movingPlatforms: [
        { x: 2980, y: 400, w: 130, h: 24, axis: "x", range: 115, speed: 1.5, style: "wood" }
      ],
      springs: [
        { x: 1210, y: 440 },
        { x: 2430, y: 440 }
      ],
      hazards: [
        { x: 930, y: 440, w: 56, kind: "bramble" },
        { x: 2770, y: 440, w: 60, kind: "bramble" }
      ],
      checkpoints: [
        { x: 1940, y: 440 }
      ],
      enemies: [
        { type: "beetle", x: 420, y: 440, minX: 300, maxX: 580, speed: 75 },
        { type: "beetle", x: 1090, y: 440, minX: 1010, maxX: 1250, speed: 85 },
        { type: "beetle", x: 2150, y: 440, minX: 2010, maxX: 2380, speed: 95 },
        { type: "beetle", x: 3460, y: 440, minX: 3270, maxX: 3620, speed: 95 }
      ],
      powerups: [
        { type: "speed", x: 515, y: 240 },
        { type: "shield", x: 2340, y: 225 },
        { type: "bonus", x: 3575, y: 240 }
      ],
      coins: [
        ...coinRow(180, 405, 3, 42),
        ...coinRow(295, 315, 3, 38),
        ...coinRow(470, 245, 3, 38),
        ...coinArc(635, 385, 3, 38, 45),
        ...coinRow(885, 320, 3, 38),
        ...coinRow(1075, 255, 4, 38),
        ...coinArc(1210, 290, 4, 42, 48),
        ...coinRow(1435, 365, 3, 38),
        ...coinRow(1675, 310, 3, 38),
        ...coinRow(2075, 305, 3, 42),
        ...coinRow(2285, 230, 3, 42),
        ...coinArc(2430, 295, 4, 45, 55),
        ...coinRow(2675, 405, 3, 38),
        ...coinRow(3005, 345, 4, 42),
        ...coinRow(3345, 310, 3, 38),
        ...coinRow(3440, 405, 4, 40),
        ...coinArc(3590, 360, 3, 38, 35)
      ]
    },

    // =========================================================================
    // LEVEL 2: HIGHWIND MOUNTAIN ADVENTURE
    // =========================================================================
    {
      id: 2,
      name: "Highwind Peaks",
      subtitle: "Alpine ledges, sky lifts & breezy ridge jumps",
      difficulty: "Medium",
      theme: "mountain",
      width: 4550,
      spawn: { x: 80, y: 380 },
      goal: { x: 4370, y: 420 },
      platforms: [
        // Base camp
        { x: 0, y: 440, w: 500, h: 160, style: "stone" },
        { x: 260, y: 355, w: 140, h: 24, style: "ledge" },

        // Ascending ridge
        { x: 615, y: 400, w: 220, h: 200, style: "stone" },
        { x: 945, y: 350, w: 200, h: 250, style: "stone" },
        { x: 1250, y: 420, w: 380, h: 180, style: "stone" },

        // Checkpoint 1 plateau
        { x: 1745, y: 420, w: 460, h: 180, style: "stone" },
        { x: 1880, y: 325, w: 170, h: 24, style: "ledge" },

        // Vertical sky lift & high ledge
        { x: 2510, y: 300, w: 220, h: 26, style: "ledge" },
        { x: 2840, y: 380, w: 360, h: 220, style: "stone" },

        // Checkpoint 2 plateau -> Bridge chasm -> Summit
        { x: 3320, y: 420, w: 340, h: 180, style: "stone" },
        { x: 4040, y: 420, w: 510, h: 180, style: "stone" },
        { x: 4100, y: 320, w: 150, h: 24, style: "ledge" }
      ],
      movingPlatforms: [
        { x: 2260, y: 375, w: 130, h: 24, axis: "y", range: 78, speed: 1.7, style: "ledge" },
        { x: 3710, y: 405, w: 130, h: 24, axis: "x", range: 175, speed: 1.85, style: "ledge" }
      ],
      springs: [
        { x: 1555, y: 420 },
        { x: 3120, y: 380 }
      ],
      hazards: [
        { x: 710, y: 400, w: 54, kind: "spikes" },
        { x: 1410, y: 420, w: 60, kind: "spikes" },
        { x: 2980, y: 380, w: 58, kind: "spikes" }
      ],
      checkpoints: [
        { x: 1795, y: 420 },
        { x: 3370, y: 420 }
      ],
      enemies: [
        { type: "beetle", x: 380, y: 440, minX: 250, maxX: 470, speed: 95 },
        { type: "spiky", x: 1030, y: 350, minX: 965, maxX: 1120, speed: 80 },
        { type: "bat", x: 1650, y: 250, minY: 205, maxY: 315, speed: 2.1, rangeX: 55 },
        { type: "beetle", x: 1960, y: 420, minX: 1850, maxX: 2170, speed: 110 },
        { type: "bat", x: 2770, y: 235, minY: 195, maxY: 295, speed: 2.3, rangeX: 45 },
        { type: "spiky", x: 3520, y: 420, minX: 3420, maxX: 3630, speed: 90 },
        { type: "beetle", x: 4200, y: 420, minX: 4070, maxX: 4310, speed: 115 }
      ],
      powerups: [
        { type: "shield", x: 330, y: 315 },
        { type: "speed", x: 1965, y: 285 },
        { type: "bonus", x: 2620, y: 260 }
      ],
      coins: [
        ...coinRow(170, 405, 3, 38),
        ...coinRow(285, 318, 3, 38),
        ...coinArc(520, 360, 3, 38, 40),
        ...coinRow(640, 362, 3, 40),
        ...coinRow(975, 312, 4, 38),
        ...coinRow(1290, 382, 3, 40),
        ...coinArc(1560, 275, 4, 42, 50),
        ...coinRow(1900, 285, 4, 38),
        ...coinRow(2290, 285, 3, 36),
        ...coinRow(2545, 262, 4, 40),
        ...coinRow(2880, 342, 4, 42),
        ...coinArc(3135, 250, 4, 44, 55),
        ...coinRow(3440, 382, 4, 40),
        ...coinArc(3740, 335, 5, 44, 42),
        ...coinRow(4125, 280, 3, 42),
        ...coinRow(4150, 382, 4, 40)
      ]
    },

    // =========================================================================
    // LEVEL 3: CRYSTAL TREASURE CAVE
    // =========================================================================
    {
      id: 3,
      name: "Crystal Treasure Cave",
      subtitle: "Glowing caverns, moving crystal bridges & grand treasure",
      difficulty: "Hard",
      theme: "cave",
      width: 5050,
      spawn: { x: 80, y: 380 },
      goal: { x: 4860, y: 420 },
      platforms: [
        // Cave entrance
        { x: 0, y: 440, w: 460, h: 160, style: "crystal" },
        { x: 240, y: 350, w: 140, h: 24, style: "crystalLedge" },

        // Crystal stepping stones
        { x: 580, y: 390, w: 170, h: 26, style: "crystalLedge" },
        { x: 870, y: 335, w: 180, h: 26, style: "crystalLedge" },
        { x: 1170, y: 420, w: 410, h: 180, style: "crystal" },

        // Checkpoint 1 Vault
        { x: 1980, y: 420, w: 460, h: 180, style: "crystal" },
        { x: 2120, y: 325, w: 170, h: 24, style: "crystalLedge" },

        // Twin elevators & high treasure shelf
        { x: 2770, y: 280, w: 230, h: 26, style: "crystalLedge" },
        { x: 3110, y: 400, w: 380, h: 200, style: "crystal" },

        // Checkpoint 2 -> Final Chasm -> Treasure Shrine
        { x: 3610, y: 420, w: 360, h: 180, style: "crystal" },
        { x: 4460, y: 420, w: 590, h: 180, style: "crystal" },
        { x: 4540, y: 320, w: 170, h: 24, style: "crystalLedge" }
      ],
      movingPlatforms: [
        { x: 1640, y: 385, w: 135, h: 24, axis: "x", range: 135, speed: 2.0, style: "crystalLedge" },
        { x: 2510, y: 365, w: 125, h: 24, axis: "y", range: 85, speed: 2.05, style: "crystalLedge" },
        { x: 4035, y: 400, w: 130, h: 24, axis: "x", range: 210, speed: 2.15, style: "crystalLedge" }
      ],
      springs: [
        { x: 1500, y: 420 },
        { x: 3420, y: 400 }
      ],
      hazards: [
        { x: 1290, y: 420, w: 62, kind: "crystalSpikes" },
        { x: 2210, y: 420, w: 62, kind: "crystalSpikes" },
        { x: 3260, y: 400, w: 62, kind: "crystalSpikes" },
        { x: 4630, y: 420, w: 62, kind: "crystalSpikes" }
      ],
      checkpoints: [
        { x: 2025, y: 420 },
        { x: 3660, y: 420 }
      ],
      enemies: [
        { type: "beetle", x: 350, y: 440, minX: 230, maxX: 430, speed: 105 },
        { type: "bat", x: 785, y: 265, minY: 220, maxY: 335, speed: 2.3, rangeX: 45 },
        { type: "spiky", x: 1390, y: 420, minX: 1370, maxX: 1475, speed: 85 },
        { type: "beetle", x: 2100, y: 420, minX: 2060, maxX: 2180, speed: 115 },
        { type: "bat", x: 2680, y: 235, minY: 185, maxY: 300, speed: 2.5, rangeX: 50 },
        { type: "spiky", x: 3180, y: 400, minX: 3130, maxX: 3240, speed: 95 },
        { type: "beetle", x: 3800, y: 420, minX: 3710, maxX: 3940, speed: 120 },
        { type: "bat", x: 4340, y: 290, minY: 235, maxY: 350, speed: 2.5, rangeX: 55 },
        { type: "spiky", x: 4735, y: 420, minX: 4710, maxX: 4815, speed: 95 }
      ],
      powerups: [
        { type: "shield", x: 310, y: 310 },
        { type: "bonus", x: 2205, y: 285 },
        { type: "speed", x: 2885, y: 240 },
        { type: "shield", x: 4625, y: 280 }
      ],
      coins: [
        ...coinRow(170, 405, 3, 36),
        ...coinRow(260, 310, 3, 38),
        ...coinRow(605, 352, 4, 38),
        ...coinRow(895, 297, 4, 38),
        ...coinRow(1210, 382, 3, 36),
        ...coinArc(1505, 280, 4, 42, 48),
        ...coinRow(1685, 335, 4, 42),
        ...coinRow(2145, 285, 4, 38),
        ...coinRow(2535, 265, 3, 36),
        ...coinRow(2805, 240, 5, 38),
        ...coinRow(3145, 362, 3, 36),
        ...coinArc(3420, 265, 4, 42, 52),
        ...coinRow(3735, 382, 5, 38),
        ...coinArc(4090, 325, 6, 44, 44),
        ...coinRow(4565, 280, 4, 38),
        ...coinRow(4500, 382, 3, 36),
        ...coinArc(4730, 330, 4, 38, 42)
      ]
    }
  ];

  function getLevel(id) {
    return LEVELS.find((lvl) => lvl.id === id) || LEVELS[0];
  }

  function getAll() {
    return LEVELS;
  }

  return {
    getLevel,
    getAll
  };
})();
