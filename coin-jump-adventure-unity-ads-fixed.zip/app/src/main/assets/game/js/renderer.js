/**
 * High-polish HTML5 Canvas 2D Renderer for Coin Jump Adventure.
 * Renders multi-layer parallax worlds, expressive animated rabbit hero,
 * spinning gold coins, power-ups, enemies, checkpoints, and particle FX.
 */
window.GameRenderer = (function () {
  const THEMES = {
    forest: {
      skyTop: "#38bdf8",
      skyBottom: "#bae6fd",
      sunColor: "#fef08a",
      hillBack: "#34d399",
      hillMid: "#10b981",
      hillFront: "#059669",
      groundFill: "#6b4423",
      groundDark: "#4a2e16",
      topCap: "#22c55e",
      topHighlight: "#86efac",
      woodFill: "#a16207",
      woodTop: "#ca8a04"
    },
    mountain: {
      skyTop: "#1d4ed8",
      skyBottom: "#fde68a",
      sunColor: "#fffbeb",
      hillBack: "#64748b",
      hillMid: "#475569",
      hillFront: "#334155",
      groundFill: "#475569",
      groundDark: "#334155",
      topCap: "#e2e8f0",
      topHighlight: "#ffffff",
      woodFill: "#78716c",
      woodTop: "#d6d3d1"
    },
    cave: {
      skyTop: "#0f0720",
      skyBottom: "#2e1065",
      sunColor: "#a855f7",
      hillBack: "#1e1b4b",
      hillMid: "#31105e",
      hillFront: "#1f093d",
      groundFill: "#271b45",
      groundDark: "#191030",
      topCap: "#8b5cf6",
      topHighlight: "#ddd6fe",
      woodFill: "#4c1d95",
      woodTop: "#a78bfa"
    }
  };

  function drawRoundedRect(ctx, x, y, w, h, r) {
    const rad = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + rad, y);
    ctx.lineTo(x + w - rad, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + rad);
    ctx.lineTo(x + w, y + h - rad);
    ctx.quadraticCurveTo(x + w, y + h, x + w - rad, y + h);
    ctx.lineTo(x + rad, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - rad);
    ctx.lineTo(x, y + rad);
    ctx.quadraticCurveTo(x, y, x + rad, y);
    ctx.closePath();
  }

  function drawBackground(ctx, themeName, camX, vw, vh, time) {
    const t = THEMES[themeName] || THEMES.forest;

    // Sky gradient
    const grad = ctx.createLinearGradient(0, 0, 0, vh);
    grad.addColorStop(0, t.skyTop);
    grad.addColorStop(1, t.skyBottom);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, vw, vh);

    if (themeName === "cave") {
      // Glowing underground cavern ceiling & ambient crystals
      ctx.fillStyle = "#160a2e";
      ctx.beginPath();
      ctx.moveTo(0, 0);
      for (let x = 0; x <= vw + 80; x += 70) {
        const worldX = x + camX * 0.2;
        const drop = 42 + Math.sin(worldX * 0.013) * 24 + Math.cos(worldX * 0.031) * 14;
        ctx.lineTo(x, drop);
      }
      ctx.lineTo(vw, 0);
      ctx.closePath();
      ctx.fill();

      // Twinkling cave crystals / glow motes
      for (let i = 0; i < 16; i++) {
        const px = ((i * 190 - camX * 0.18) % (vw + 140) + (vw + 140)) % (vw + 140) - 70;
        const py = 75 + ((i * 97) % Math.max(120, vh * 0.65));
        const pulse = 0.4 + 0.6 * Math.sin(time * 2.2 + i);
        ctx.fillStyle = i % 2 === 0
          ? `rgba(103, 232, 249, ${0.22 * pulse})`
          : `rgba(216, 180, 254, ${0.25 * pulse})`;
        ctx.beginPath();
        ctx.arc(px, py, 10 + (i % 4) * 4, 0, Math.PI * 2);
        ctx.fill();
      }
    } else {
      // Sun / Alpine Sun Halo
      const sunX = vw * 0.78 - camX * 0.03;
      const sunY = vh * 0.2;
      const sunGlow = ctx.createRadialGradient(sunX, sunY, 10, sunX, sunY, 95);
      sunGlow.addColorStop(0, "rgba(255, 251, 214, 0.95)");
      sunGlow.addColorStop(0.4, "rgba(254, 240, 138, 0.35)");
      sunGlow.addColorStop(1, "rgba(254, 240, 138, 0)");
      ctx.fillStyle = sunGlow;
      ctx.beginPath();
      ctx.arc(sunX, sunY, 95, 0, Math.PI * 2);
      ctx.fill();

      // Fluffy parallax clouds
      ctx.fillStyle = themeName === "mountain" ? "rgba(255,255,255,0.75)" : "rgba(255,255,255,0.88)";
      for (let i = 0; i < 7; i++) {
        const span = vw + 260;
        const cx = (((i * 230 - camX * 0.12 - time * 8) % span) + span) % span - 130;
        const cy = 62 + (i % 3) * 46;
        const sc = 0.8 + (i % 3) * 0.22;
        ctx.beginPath();
        ctx.arc(cx, cy, 20 * sc, 0, Math.PI * 2);
        ctx.arc(cx + 22 * sc, cy - 8 * sc, 25 * sc, 0, Math.PI * 2);
        ctx.arc(cx + 46 * sc, cy, 19 * sc, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Back Mountains / Silhouettes
    ctx.fillStyle = t.hillBack;
    ctx.beginPath();
    ctx.moveTo(0, vh);
    for (let x = -40; x <= vw + 80; x += 90) {
      const wx = x + camX * 0.18;
      const peak = themeName === "mountain"
        ? vh * 0.45 + Math.abs(Math.sin(wx * 0.0055)) * -125
        : vh * 0.62 + Math.sin(wx * 0.0045) * 48;
      ctx.lineTo(x, peak);
    }
    ctx.lineTo(vw + 80, vh);
    ctx.closePath();
    ctx.fill();

    // Snow caps on Mountain Adventure
    if (themeName === "mountain") {
      ctx.fillStyle = "rgba(248, 250, 252, 0.85)";
      for (let i = -1; i < Math.ceil(vw / 180) + 2; i++) {
        const base = i * 180 - ((camX * 0.18) % 180);
        const peakY = vh * 0.34 + ((i % 2) * 28);
        ctx.beginPath();
        ctx.moveTo(base + 90, peakY);
        ctx.lineTo(base + 58, peakY + 42);
        ctx.lineTo(base + 78, peakY + 34);
        ctx.lineTo(base + 92, peakY + 45);
        ctx.lineTo(base + 118, peakY + 38);
        ctx.closePath();
        ctx.fill();
      }
    }

    // Midground hills
    ctx.fillStyle = t.hillMid;
    ctx.beginPath();
    ctx.moveTo(0, vh);
    for (let x = 0; x <= vw + 60; x += 60) {
      const wx = x + camX * 0.35;
      const y = vh * 0.72 + Math.sin(wx * 0.0065) * 36 + Math.cos(wx * 0.011) * 16;
      ctx.lineTo(x, y);
    }
    ctx.lineTo(vw + 60, vh);
    ctx.closePath();
    ctx.fill();

    // Scenery Trees / Cave Pillars
    const step = 210;
    const firstIdx = Math.floor((camX * 0.52) / step) - 1;
    const lastIdx = firstIdx + Math.ceil(vw / step) + 3;
    for (let idx = firstIdx; idx <= lastIdx; idx++) {
      const sx = idx * step - camX * 0.52;
      const sy = vh * 0.75 + Math.sin(idx * 2.1) * 18;
      if (themeName === "forest") {
        // Lush pine/round forest tree
        ctx.fillStyle = "#5c3a21";
        ctx.fillRect(sx - 7, sy - 42, 14, 70);
        ctx.fillStyle = "#166534";
        ctx.beginPath();
        ctx.arc(sx, sy - 58, 30, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#22c55e";
        ctx.beginPath();
        ctx.arc(sx - 12, sy - 66, 20, 0, Math.PI * 2);
        ctx.arc(sx + 13, sy - 62, 18, 0, Math.PI * 2);
        ctx.fill();
      } else if (themeName === "mountain") {
        // Alpine pine
        ctx.fillStyle = "#3f2e21";
        ctx.fillRect(sx - 5, sy - 26, 10, 50);
        ctx.fillStyle = "#0f766e";
        ctx.beginPath();
        ctx.moveTo(sx, sy - 76);
        ctx.lineTo(sx - 24, sy - 24);
        ctx.lineTo(sx + 24, sy - 24);
        ctx.closePath();
        ctx.fill();
      } else {
        // Glowing cave crystal cluster
        ctx.fillStyle = idx % 2 === 0 ? "rgba(56, 189, 248, 0.38)" : "rgba(192, 132, 252, 0.38)";
        ctx.beginPath();
        ctx.moveTo(sx - 14, sy + 20);
        ctx.lineTo(sx - 5, sy - 52);
        ctx.lineTo(sx + 8, sy + 20);
        ctx.closePath();
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(sx + 2, sy + 20);
        ctx.lineTo(sx + 16, sy - 34);
        ctx.lineTo(sx + 24, sy + 20);
        ctx.closePath();
        ctx.fill();
      }
    }
  }

  function drawPlatforms(ctx, world, themeName, camX, vw) {
    const t = THEMES[themeName] || THEMES.forest;
    const allPlats = world.platforms.concat(world.movingPlatforms);

    allPlats.forEach((p) => {
      if (p.x + p.w < camX - 40 || p.x > camX + vw + 40) return;
      const isLedge = p.style === "wood" || p.style === "ledge" || p.style === "crystalLedge";

      if (isLedge) {
        drawRoundedRect(ctx, p.x, p.y, p.w, p.h, 8);
        ctx.fillStyle = t.woodFill;
        ctx.fill();

        drawRoundedRect(ctx, p.x, p.y, p.w, Math.min(10, p.h * 0.45), 7);
        ctx.fillStyle = t.woodTop;
        ctx.fill();

        // Subtle plank / rivet accents
        ctx.fillStyle = "rgba(255,255,255,0.22)";
        ctx.fillRect(p.x + 10, p.y + 3, p.w - 20, 2);
      } else {
        // Solid ground block
        drawRoundedRect(ctx, p.x, p.y, p.w, p.h, 10);
        ctx.fillStyle = t.groundFill;
        ctx.fill();

        // Texture pebbles
        ctx.fillStyle = t.groundDark;
        for (let px = p.x + 22; px < p.x + p.w - 22; px += 48) {
          ctx.beginPath();
          ctx.arc(px, p.y + 34, 5, 0, Math.PI * 2);
          ctx.arc(px + 20, p.y + 58, 3.5, 0, Math.PI * 2);
          ctx.fill();
        }

        // Lush top turf / snow / crystal cap
        drawRoundedRect(ctx, p.x - 2, p.y, p.w + 4, 16, 8);
        ctx.fillStyle = t.topCap;
        ctx.fill();

        ctx.fillStyle = t.topHighlight;
        ctx.fillRect(p.x + 8, p.y + 3, p.w - 16, 3);

        // Forest wildflowers or cave glowing moss tufts
        if (themeName === "forest") {
          for (let fx = p.x + 28; fx < p.x + p.w - 28; fx += 78) {
            ctx.fillStyle = "#fde047";
            ctx.beginPath();
            ctx.arc(fx, p.y - 3, 3.5, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = "#fb7185";
            ctx.beginPath();
            ctx.arc(fx + 14, p.y - 2, 3, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      }
    });
  }

  function drawSprings(ctx, springs) {
    springs.forEach((sp) => {
      const compress = sp.bounceAnim > 0 ? Math.sin(sp.bounceAnim * Math.PI) * 6 : 0;
      const topY = sp.y - sp.h + compress;
      // Stem
      ctx.fillStyle = "#fef3c7";
      ctx.fillRect(sp.x + 12, topY + 7, 14, sp.y - topY - 7);
      // Bouncy cap
      ctx.fillStyle = "#f43f5e";
      drawRoundedRect(ctx, sp.x, topY, sp.w, 12, 6);
      ctx.fill();
      ctx.fillStyle = "#ffe4e6";
      ctx.beginPath();
      ctx.arc(sp.x + 11, topY + 5, 3, 0, Math.PI * 2);
      ctx.arc(sp.x + 27, topY + 5, 2.5, 0, Math.PI * 2);
      ctx.fill();
    });
  }

  function drawHazards(ctx, hazards, time) {
    hazards.forEach((hz) => {
      const spikes = Math.max(3, Math.floor(hz.w / 14));
      const sw = hz.w / spikes;
      for (let i = 0; i < spikes; i++) {
        const sx = hz.x + i * sw;
        ctx.beginPath();
        ctx.moveTo(sx, hz.y);
        ctx.lineTo(sx + sw * 0.5, hz.y - hz.h - Math.sin(time * 4 + i) * 1.2);
        ctx.lineTo(sx + sw, hz.y);
        ctx.closePath();
        if (hz.kind === "bramble") {
          ctx.fillStyle = "#be123c";
        } else if (hz.kind === "crystalSpikes") {
          ctx.fillStyle = "#e879f9";
        } else {
          ctx.fillStyle = "#cbd5e1";
        }
        ctx.fill();
        ctx.strokeStyle = "rgba(15, 23, 42, 0.55)";
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }
    });
  }

  function drawCheckpoints(ctx, checkpoints, time) {
    checkpoints.forEach((cp) => {
      // Wooden post
      ctx.fillStyle = "#78350f";
      ctx.fillRect(cp.x - 3, cp.y - 62, 6, 62);
      // Flag
      const wave = Math.sin(time * 5) * 3;
      ctx.beginPath();
      ctx.moveTo(cp.x + 3, cp.y - 58);
      ctx.lineTo(cp.x + 34, cp.y - 48 + wave);
      ctx.lineTo(cp.x + 3, cp.y - 36);
      ctx.closePath();
      ctx.fillStyle = cp.activated ? "#22c55e" : "#94a3b8";
      ctx.fill();

      // Lantern orb on top
      if (cp.activated) {
        const glow = ctx.createRadialGradient(cp.x, cp.y - 66, 2, cp.x, cp.y - 66, 24);
        glow.addColorStop(0, "rgba(253, 224, 71, 0.95)");
        glow.addColorStop(1, "rgba(253, 224, 71, 0)");
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(cp.x, cp.y - 66, 24, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = cp.activated ? "#fde047" : "#e2e8f0";
      ctx.beginPath();
      ctx.arc(cp.x, cp.y - 66, 6, 0, Math.PI * 2);
      ctx.fill();
    });
  }

  function drawGoal(ctx, goal, time) {
    const gx = goal.x;
    const gy = goal.y;

    // Archway pillars
    ctx.fillStyle = "#fde68a";
    drawRoundedRect(ctx, gx - 34, gy - 92, 68, 92, 34);
    ctx.strokeStyle = "#f59e0b";
    ctx.lineWidth = 5;
    ctx.stroke();

    // Swirl portal
    const pulse = 0.88 + Math.sin(time * 4) * 0.1;
    const portalGrad = ctx.createRadialGradient(gx, gy - 48, 4, gx, gy - 48, 30 * pulse);
    portalGrad.addColorStop(0, "#ffffff");
    portalGrad.addColorStop(0.45, "#fde047");
    portalGrad.addColorStop(1, "rgba(20, 184, 166, 0.35)");
    ctx.fillStyle = portalGrad;
    ctx.beginPath();
    ctx.ellipse(gx, gy - 46, 22 * pulse, 36 * pulse, 0, 0, Math.PI * 2);
    ctx.fill();

    // Floating Crown Star above arch
    const starY = gy - 108 + Math.sin(time * 3) * 5;
    drawStarShape(ctx, gx, starY, 5, 13, 6, "#ffd447", "#ffffff");
  }

  function drawStarShape(ctx, cx, cy, spikes, outerR, innerR, fill, stroke) {
    let rot = (Math.PI / 2) * 3;
    const step = Math.PI / spikes;
    ctx.beginPath();
    ctx.moveTo(cx, cy - outerR);
    for (let i = 0; i < spikes; i++) {
      ctx.lineTo(cx + Math.cos(rot) * outerR, cy + Math.sin(rot) * outerR);
      rot += step;
      ctx.lineTo(cx + Math.cos(rot) * innerR, cy + Math.sin(rot) * innerR);
      rot += step;
    }
    ctx.closePath();
    ctx.fillStyle = fill;
    ctx.fill();
    if (stroke) {
      ctx.strokeStyle = stroke;
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }
  }

  function drawCoins(ctx, coins, time, camX, vw) {
    coins.forEach((c) => {
      if (c.collected) return;
      if (c.x < camX - 30 || c.x > camX + vw + 30) return;

      const bobY = c.y + Math.sin(time * 3.8 + c.phase) * 4.5;
      const spinScale = 0.32 + 0.68 * Math.abs(Math.cos(time * 4.2 + c.phase));

      ctx.save();
      ctx.translate(c.x, bobY);

      // Soft golden halo
      ctx.fillStyle = "rgba(253, 224, 71, 0.22)";
      ctx.beginPath();
      ctx.arc(0, 0, c.r + 5, 0, Math.PI * 2);
      ctx.fill();

      ctx.scale(spinScale, 1);
      // Outer rim
      ctx.fillStyle = "#f59e0b";
      ctx.beginPath();
      ctx.arc(0, 0, c.r, 0, Math.PI * 2);
      ctx.fill();

      // Bright gold face
      ctx.fillStyle = "#fde047";
      ctx.beginPath();
      ctx.arc(0, 0, c.r - 2.5, 0, Math.PI * 2);
      ctx.fill();

      // Inner embossed shine
      ctx.strokeStyle = "#fffbeb";
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.arc(0, 0, c.r - 5, -0.8, 1.5);
      ctx.stroke();

      ctx.fillStyle = "#b45309";
      ctx.fillRect(-2, -5.5, 4, 11);
      ctx.restore();
    });
  }

  function drawPowerups(ctx, powerups, time) {
    powerups.forEach((pu) => {
      if (pu.collected) return;
      const py = pu.baseY + Math.sin(time * 3.5 + pu.phase) * 6;
      ctx.save();
      ctx.translate(pu.x, py);

      // Radiant aura
      const auraColor =
        pu.type === "speed"
          ? "rgba(34, 211, 238, 0.35)"
          : pu.type === "shield"
          ? "rgba(96, 165, 250, 0.35)"
          : "rgba(251, 191, 36, 0.4)";

      ctx.fillStyle = auraColor;
      ctx.beginPath();
      ctx.arc(0, 0, pu.r + 8 + Math.sin(time * 6) * 2, 0, Math.PI * 2);
      ctx.fill();

      // Orb shell
      ctx.fillStyle =
        pu.type === "speed" ? "#06b6d4" : pu.type === "shield" ? "#3b82f6" : "#f59e0b";
      ctx.beginPath();
      ctx.arc(0, 0, pu.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = "#ffffff";
      ctx.stroke();

      // Distinct symbol inside
      ctx.fillStyle = "#ffffff";
      if (pu.type === "speed") {
        // Lightning bolt
        ctx.beginPath();
        ctx.moveTo(2, -9);
        ctx.lineTo(-6, 1);
        ctx.lineTo(0, 1);
        ctx.lineTo(-3, 9);
        ctx.lineTo(6, -1);
        ctx.lineTo(0, -1);
        ctx.closePath();
        ctx.fill();
      } else if (pu.type === "shield") {
        // Shield crest
        ctx.beginPath();
        ctx.moveTo(0, -8);
        ctx.lineTo(7, -5);
        ctx.lineTo(6, 3);
        ctx.lineTo(0, 9);
        ctx.lineTo(-6, 3);
        ctx.lineTo(-7, -5);
        ctx.closePath();
        ctx.fill();
      } else {
        // Golden Star Coin Bonus
        drawStarShape(ctx, 0, 0, 5, 9, 4.2, "#fef08a", "#ffffff");
      }

      ctx.restore();
    });
  }

  function drawEnemies(ctx, enemies, time) {
    enemies.forEach((e) => {
      if (!e.alive && e.squishTimer <= 0) return;
      ctx.save();
      const cx = e.x + e.w / 2;
      const cy = e.y - e.h / 2;
      ctx.translate(cx, e.y);
      if (!e.alive) {
        ctx.scale(1.3, 0.35);
      }

      if (e.type === "beetle") {
        // Cute grumpy forest beetle
        const bob = Math.abs(Math.sin(time * 9 + e.phase)) * 2;
        ctx.fillStyle = "#7c3aed";
        ctx.beginPath();
        ctx.arc(0, -12 - bob, 16, Math.PI, 0);
        ctx.lineTo(16, -4 - bob);
        ctx.lineTo(-16, -4 - bob);
        ctx.closePath();
        ctx.fill();

        // Spots
        ctx.fillStyle = "#ddd6fe";
        ctx.beginPath();
        ctx.arc(-6, -18 - bob, 3.5, 0, Math.PI * 2);
        ctx.arc(7, -16 - bob, 2.8, 0, Math.PI * 2);
        ctx.fill();

        // Eyes
        const look = e.dir * 3;
        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.arc(look - 4, -10 - bob, 4, 0, Math.PI * 2);
        ctx.arc(look + 5, -10 - bob, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#0f172a";
        ctx.beginPath();
        ctx.arc(look - 3.5, -10 - bob, 2, 0, Math.PI * 2);
        ctx.arc(look + 5.5, -10 - bob, 2, 0, Math.PI * 2);
        ctx.fill();

        // Little feet
        ctx.fillStyle = "#1e1b4b";
        const footShift = Math.sin(time * 12) * 3;
        ctx.fillRect(-11 + footShift, -4, 7, 4);
        ctx.fillRect(4 - footShift, -4, 7, 4);
      } else if (e.type === "spiky") {
        // Armored rock crab (spiky top - do not stomp!)
        ctx.fillStyle = "#dc2626";
        ctx.beginPath();
        ctx.arc(0, -11, 15, Math.PI, 0);
        ctx.lineTo(15, -3);
        ctx.lineTo(-15, -3);
        ctx.closePath();
        ctx.fill();

        // Warning dorsal spikes
        ctx.fillStyle = "#fef08a";
        [-9, 0, 9].forEach((sx) => {
          ctx.beginPath();
          ctx.moveTo(sx - 4, -22);
          ctx.lineTo(sx, -31);
          ctx.lineTo(sx + 4, -22);
          ctx.closePath();
          ctx.fill();
        });

        // Eyes
        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.arc(-5, -10, 3.5, 0, Math.PI * 2);
        ctx.arc(5, -10, 3.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#0f172a";
        ctx.beginPath();
        ctx.arc(-5 + e.dir * 1.2, -10, 1.8, 0, Math.PI * 2);
        ctx.arc(5 + e.dir * 1.2, -10, 1.8, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Flutter Bat
        const flap = Math.sin(time * 14 + e.phase) * 9;
        ctx.translate(0, -14);
        // Wings
        ctx.fillStyle = "#4338ca";
        ctx.beginPath();
        ctx.moveTo(-4, 0);
        ctx.quadraticCurveTo(-18, -14 + flap, -24, 2 + flap * 0.5);
        ctx.lineTo(-6, 5);
        ctx.closePath();
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(4, 0);
        ctx.quadraticCurveTo(18, -14 + flap, 24, 2 + flap * 0.5);
        ctx.lineTo(6, 5);
        ctx.closePath();
        ctx.fill();

        // Body
        ctx.fillStyle = "#312e81";
        ctx.beginPath();
        ctx.arc(0, 0, 11, 0, Math.PI * 2);
        ctx.fill();

        // Cute bat ears
        ctx.beginPath();
        ctx.moveTo(-8, -7);
        ctx.lineTo(-10, -16);
        ctx.lineTo(-3, -10);
        ctx.moveTo(8, -7);
        ctx.lineTo(10, -16);
        ctx.lineTo(3, -10);
        ctx.fill();

        // Glowing amber eyes
        ctx.fillStyle = "#fde047";
        ctx.beginPath();
        ctx.arc(-4, -1, 2.5, 0, Math.PI * 2);
        ctx.arc(4, -1, 2.5, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    });
  }

  /**
   * Expressive, original White Rabbit hero ("Pip").
   * Shared by both the gameplay canvas and the Start Screen mascot preview!
   */
  function drawRabbit(ctx, opts) {
    const x = opts.x;
    const y = opts.y; // bottom-center of rabbit
    const facing = opts.facing || 1;
    const squashX = opts.squashX || 1;
    const squashY = opts.squashY || 1;
    const vx = opts.vx || 0;
    const vy = opts.vy || 0;
    const grounded = opts.grounded !== false;
    const runCycle = opts.runCycle || 0;
    const isBlinking = Boolean(opts.isBlinking);
    const hasShield = Boolean(opts.hasShield);
    const hasSpeed = Boolean(opts.hasSpeed);
    const invulnFlash = Boolean(opts.invulnFlash);
    const time = opts.time || 0;

    if (invulnFlash && Math.floor(time * 18) % 2 === 0) {
      return;
    }

    ctx.save();
    ctx.translate(x, y);

    // Shield Aura
    if (hasShield) {
      const pulse = 1 + Math.sin(time * 6) * 0.05;
      ctx.save();
      ctx.strokeStyle = "rgba(103, 232, 249, 0.9)";
      ctx.fillStyle = "rgba(56, 189, 248, 0.18)";
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(0, -24, 30 * pulse, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    ctx.scale(facing * squashX, squashY);

    // Slight forward lean while running
    const lean = grounded ? Math.min(0.14, Math.abs(vx) / 2600) : Math.max(-0.14, Math.min(0.14, vy / 3400));
    ctx.rotate(lean);

    const isRunning = grounded && Math.abs(vx) > 20;
    const hopOffset = isRunning ? Math.abs(Math.sin(runCycle * 2)) * -3.5 : Math.sin(time * 3.5) * -1.2;
    ctx.translate(0, hopOffset);

    const earSwing = !grounded
      ? Math.max(-0.45, Math.min(0.45, -vy * 0.0005))
      : isRunning
      ? -0.25 + Math.sin(runCycle * 2) * 0.12
      : Math.sin(time * 2.2) * 0.06;

    const legSwing = isRunning ? Math.sin(runCycle * 2) * 7 : !grounded ? 5 : 0;

    // Fluffy round tail
    ctx.fillStyle = "#f1f5f9";
    ctx.strokeStyle = "#cbd5e1";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(-13, -12, 6.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Back leg
    ctx.fillStyle = "#e2e8f0";
    ctx.beginPath();
    ctx.ellipse(-4 - legSwing * 0.5, -5, 6.5, 4.5, 0, 0, Math.PI * 2);
    ctx.fill();

    // Torso (soft creamy white)
    ctx.fillStyle = "#ffffff";
    ctx.strokeStyle = "#cbd5e1";
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.ellipse(0, -17, 12, 13, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Front leg
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.ellipse(5 + legSwing * 0.65, -4, 7, 4.5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Teal adventurer scarf + trailing tails
    const scarfWave = Math.sin(time * 10 + runCycle) * 3;
    ctx.fillStyle = hasSpeed ? "#06b6d4" : "#14b8a6";
    ctx.beginPath();
    ctx.moveTo(-8, -26);
    ctx.quadraticCurveTo(-20, -27 + scarfWave, -24, -20 + scarfWave);
    ctx.lineTo(-10, -21);
    ctx.closePath();
    ctx.fill();

    ctx.beginPath();
    ctx.ellipse(1, -26, 11.5, 4, 0, 0, Math.PI * 2);
    ctx.fill();

    // Back Ear
    ctx.save();
    ctx.translate(-3, -38);
    ctx.rotate(-0.22 + earSwing);
    ctx.fillStyle = "#f8fafc";
    ctx.strokeStyle = "#cbd5e1";
    ctx.beginPath();
    ctx.ellipse(0, -10, 4.8, 12, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = "#fda4af";
    ctx.beginPath();
    ctx.ellipse(0.5, -9, 2.3, 8, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Head
    ctx.fillStyle = "#ffffff";
    ctx.strokeStyle = "#cbd5e1";
    ctx.beginPath();
    ctx.ellipse(2, -33, 12.5, 11, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Front Ear
    ctx.save();
    ctx.translate(3, -40);
    ctx.rotate(0.08 + earSwing * 1.15);
    ctx.fillStyle = "#ffffff";
    ctx.strokeStyle = "#cbd5e1";
    ctx.beginPath();
    ctx.ellipse(0, -11, 5, 12.5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = "#fb7185";
    ctx.beginPath();
    ctx.ellipse(0.6, -10, 2.4, 8.2, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Rosy cheek
    ctx.fillStyle = "rgba(251, 113, 133, 0.38)";
    ctx.beginPath();
    ctx.ellipse(8, -29, 3.5, 2.2, 0, 0, Math.PI * 2);
    ctx.fill();

    // Expressive Eye
    if (isBlinking) {
      ctx.strokeStyle = "#1e293b";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(5, -34);
      ctx.lineTo(10, -34);
      ctx.stroke();
    } else {
      ctx.fillStyle = "#0f172a";
      ctx.beginPath();
      ctx.ellipse(8, -34, 2.7, 3.4, 0, 0, Math.PI * 2);
      ctx.fill();
      // Eye sparkle
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(9, -35.2, 1.1, 0, Math.PI * 2);
      ctx.fill();
    }

    // Cute pink nose & smile
    ctx.fillStyle = "#f43f5e";
    ctx.beginPath();
    ctx.ellipse(13.5, -31.5, 2.2, 1.7, 0, 0, Math.PI * 2);
    ctx.fill();

    // Little front paw
    ctx.fillStyle = "#ffffff";
    ctx.strokeStyle = "#cbd5e1";
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.ellipse(8 + legSwing * 0.3, -15, 4.5, 3.5, 0.3, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    ctx.restore();
  }

  function drawParticles(ctx, particles, floatingTexts) {
    particles.forEach((p) => {
      const alpha = Math.max(0, p.life / p.maxLife);
      ctx.save();
      ctx.globalAlpha = alpha;
      if (p.star) {
        drawStarShape(ctx, p.x, p.y, 4, p.r * 1.4, p.r * 0.55, p.color);
      } else {
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    });

    floatingTexts.forEach((ft) => {
      const alpha = Math.max(0, ft.life / ft.maxLife);
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.font = "900 15px 'Trebuchet MS', sans-serif";
      ctx.textAlign = "center";
      ctx.lineWidth = 3.5;
      ctx.strokeStyle = "rgba(15, 23, 42, 0.85)";
      ctx.strokeText(ft.text, ft.x, ft.y);
      ctx.fillStyle = ft.color;
      ctx.fillText(ft.text, ft.x, ft.y);
      ctx.restore();
    });
  }

  function renderWorld(ctx, state, vw, vh) {
    const time = state.time;
    const level = state.level;
    const world = state.world;
    const player = state.player;
    const camX = state.camX;
    const camY = state.camY;

    ctx.save();
    // Subtle screen shake
    const shakeX = state.shake > 0 ? (Math.random() - 0.5) * state.shake * 10 : 0;
    const shakeY = state.shake > 0 ? (Math.random() - 0.5) * state.shake * 10 : 0;

    drawBackground(ctx, level.theme, camX, vw, vh, time);

    ctx.translate(-camX + shakeX, -camY + shakeY);

    drawPlatforms(ctx, world, level.theme, camX, vw);
    drawSprings(ctx, world.springs);
    drawHazards(ctx, world.hazards, time);
    drawCheckpoints(ctx, world.checkpoints, time);
    drawGoal(ctx, level.goal, time);
    drawCoins(ctx, world.coins, time, camX, vw);
    drawPowerups(ctx, world.powerups, time);
    drawEnemies(ctx, world.enemies, time);

    // Speed boost motion trail
    if (player.trail.length > 0) {
      player.trail.forEach((tr) => {
        ctx.save();
        ctx.globalAlpha = tr.alpha * 0.32;
        ctx.fillStyle = "#67e8f9";
        ctx.beginPath();
        ctx.ellipse(tr.x, tr.y - 22, 14, 20, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });
    }

    drawRabbit(ctx, {
      x: player.x + player.w / 2,
      y: player.y + player.h,
      facing: player.facing,
      squashX: player.squashX,
      squashY: player.squashY,
      vx: player.vx,
      vy: player.vy,
      grounded: player.grounded,
      runCycle: player.runCycle,
      isBlinking: player.isBlinking,
      hasShield: player.shieldTimer > 0,
      hasSpeed: player.speedTimer > 0,
      invulnFlash: player.invulnTimer > 0,
      time
    });

    drawParticles(ctx, world.particles, world.floatingTexts);
    ctx.restore();
  }

  return {
    renderWorld,
    drawRabbit
  };
})();
