/**
 * Local persistence layer for Coin Jump Adventure.
 * Uses Android SharedPreferences bridge when running inside the Android app,
 * and falls back cleanly to browser localStorage on mobile/desktop browsers.
 */
window.GameStorage = (function () {
  const STORAGE_KEY = "coin_jump_adventure_save_v1";

  const DEFAULT_DATA = {
    bestScore: 0,
    totalCoins: 0,
    settings: {
      musicVolume: 0.7,
      sfxVolume: 0.85,
      muted: false,
      touchMode: "auto" // "auto" | "on" | "off"
    },
    levels: {
      1: { completed: false, stars: 0, bestScore: 0, bestCoins: 0 },
      2: { completed: false, stars: 0, bestScore: 0, bestCoins: 0 },
      3: { completed: false, stars: 0, bestScore: 0, bestCoins: 0 }
    }
  };

  function deepClone(obj) {
    return JSON.parse(JSON.stringify(obj));
  }

  function readRaw() {
    try {
      if (window.AndroidStorage && typeof window.AndroidStorage.getItem === "function") {
        const val = window.AndroidStorage.getItem(STORAGE_KEY);
        if (val) return val;
      }
    } catch (_) {
      // Ignore bridge error and try localStorage
    }
    try {
      return window.localStorage.getItem(STORAGE_KEY);
    } catch (_) {
      return null;
    }
  }

  function writeRaw(json) {
    try {
      if (window.AndroidStorage && typeof window.AndroidStorage.setItem === "function") {
        window.AndroidStorage.setItem(STORAGE_KEY, json);
      }
    } catch (_) {
      // Ignore bridge error
    }
    try {
      window.localStorage.setItem(STORAGE_KEY, json);
    } catch (_) {
      // Ignore storage quota / privacy error
    }
  }

  function load() {
    const base = deepClone(DEFAULT_DATA);
    const raw = readRaw();
    if (!raw) return base;
    try {
      const parsed = JSON.parse(raw);
      if (typeof parsed.bestScore === "number") base.bestScore = parsed.bestScore;
      if (typeof parsed.totalCoins === "number") base.totalCoins = parsed.totalCoins;
      if (parsed.settings) {
        if (typeof parsed.settings.musicVolume === "number") {
          base.settings.musicVolume = Math.max(0, Math.min(1, parsed.settings.musicVolume));
        }
        if (typeof parsed.settings.sfxVolume === "number") {
          base.settings.sfxVolume = Math.max(0, Math.min(1, parsed.settings.sfxVolume));
        }
        if (typeof parsed.settings.muted === "boolean") {
          base.settings.muted = parsed.settings.muted;
        }
        if (["auto", "on", "off"].includes(parsed.settings.touchMode)) {
          base.settings.touchMode = parsed.settings.touchMode;
        }
      }
      if (parsed.levels) {
        [1, 2, 3].forEach((id) => {
          if (parsed.levels[id]) {
            base.levels[id] = {
              completed: Boolean(parsed.levels[id].completed),
              stars: Number(parsed.levels[id].stars || 0),
              bestScore: Number(parsed.levels[id].bestScore || 0),
              bestCoins: Number(parsed.levels[id].bestCoins || 0)
            };
          }
        });
      }
      return base;
    } catch (_) {
      return base;
    }
  }

  function save(data) {
    writeRaw(JSON.stringify(data));
  }

  function recordLevelResult(levelId, score, coins, stars) {
    const data = load();
    const prev = data.levels[levelId] || { completed: false, stars: 0, bestScore: 0, bestCoins: 0 };
    const isNewBest = score > prev.bestScore;

    data.levels[levelId] = {
      completed: true,
      stars: Math.max(prev.stars, stars),
      bestScore: Math.max(prev.bestScore, score),
      bestCoins: Math.max(prev.bestCoins, coins)
    };
    data.totalCoins += coins;
    data.bestScore = Math.max(data.bestScore, score);
    save(data);
    return { data, isNewBest };
  }

  function updateSettings(partialSettings) {
    const data = load();
    data.settings = Object.assign({}, data.settings, partialSettings);
    save(data);
    return data.settings;
  }

  return {
    load,
    save,
    recordLevelResult,
    updateSettings
  };
})();
