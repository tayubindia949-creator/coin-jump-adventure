/**
 * Original Web Audio API Synthesizer & Mixer for Coin Jump Adventure.
 * Designed for crystal clarity and punchy presence on Android phone speakers
 * and desktop speakers alike, with a DynamicsCompressor master bus and
 * independent Music & SFX volume channels.
 */
window.SoundEngine = (function () {
  let ctx = null;
  let masterComp = null;
  let masterGain = null;
  let musicGain = null;
  let sfxGain = null;
  let noiseBuffer = null;

  let musicVol = 0.7;
  let sfxVol = 0.85;
  let muted = false;

  let musicTimer = null;
  let musicStep = 0;
  let currentTheme = 1;
  let isMusicPlaying = false;
  let coinComboCount = 0;
  let lastCoinTime = 0;

  function ensureContext() {
    if (!ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return null;
      ctx = new AudioCtx();

      masterComp = ctx.createDynamicsCompressor();
      masterComp.threshold.setValueAtTime(-14, ctx.currentTime);
      masterComp.knee.setValueAtTime(16, ctx.currentTime);
      masterComp.ratio.setValueAtTime(5, ctx.currentTime);
      masterComp.attack.setValueAtTime(0.004, ctx.currentTime);
      masterComp.release.setValueAtTime(0.14, ctx.currentTime);

      masterGain = ctx.createGain();
      musicGain = ctx.createGain();
      sfxGain = ctx.createGain();

      // Speaker-friendly high-pass to prevent sub-bass mud on tiny phone speakers
      const speakerFilter = ctx.createBiquadFilter();
      speakerFilter.type = "highpass";
      speakerFilter.frequency.setValueAtTime(110, ctx.currentTime);

      musicGain.connect(speakerFilter);
      sfxGain.connect(speakerFilter);
      speakerFilter.connect(masterComp);
      masterComp.connect(masterGain);
      masterGain.connect(ctx.destination);

      noiseBuffer = createNoiseBuffer(ctx);
      applyVolumes();
    }
    if (ctx.state === "suspended") {
      ctx.resume().catch(() => {});
    }
    return ctx;
  }

  function createNoiseBuffer(audioCtx) {
    const length = audioCtx.sampleRate * 0.5;
    const buffer = audioCtx.createBuffer(1, length, audioCtx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < length; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    return buffer;
  }

  function applyVolumes() {
    if (!ctx) return;
    const now = ctx.currentTime;
    masterGain.gain.setTargetAtTime(muted ? 0 : 0.95, now, 0.02);
    // Keep music balanced below SFX so actions always cut through clearly
    musicGain.gain.setTargetAtTime(musicVol * 0.34, now, 0.03);
    sfxGain.gain.setTargetAtTime(sfxVol * 0.95, now, 0.02);
  }

  function unlock() {
    const c = ensureContext();
    if (!c) return;
    if (c.state === "suspended") {
      c.resume().catch(() => {});
    }
    // Silent tiny pulse to guarantee mobile audio unlock
    try {
      const osc = c.createOscillator();
      const g = c.createGain();
      g.gain.value = 0.0001;
      osc.connect(g);
      g.connect(c.destination);
      osc.start(c.currentTime);
      osc.stop(c.currentTime + 0.02);
    } catch (_) {}
  }

  function setVolumes(mVol, sVol, isMuted) {
    if (typeof mVol === "number") musicVol = Math.max(0, Math.min(1, mVol));
    if (typeof sVol === "number") sfxVol = Math.max(0, Math.min(1, sVol));
    if (typeof isMuted === "boolean") muted = isMuted;
    applyVolumes();
  }

  function midiToFreq(midi) {
    return 440 * Math.pow(2, (midi - 69) / 12);
  }

  function playTone(opts) {
    const c = ensureContext();
    if (!c || muted) return;
    const now = opts.time ?? c.currentTime;
    const dur = opts.dur ?? 0.16;
    const dest = opts.bus === "music" ? musicGain : sfxGain;

    const osc = c.createOscillator();
    const gain = c.createGain();
    osc.type = opts.type || "triangle";
    osc.frequency.setValueAtTime(opts.freq, now);
    if (opts.freqEnd) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(30, opts.freqEnd), now + dur);
    }

    const peak = opts.vol ?? 0.3;
    const attack = opts.attack ?? 0.008;
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(peak, now + attack);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);

    if (opts.filterFreq) {
      const filter = c.createBiquadFilter();
      filter.type = opts.filterType || "lowpass";
      filter.frequency.setValueAtTime(opts.filterFreq, now);
      osc.connect(filter);
      filter.connect(gain);
    } else {
      osc.connect(gain);
    }

    gain.connect(dest);
    osc.start(now);
    osc.stop(now + dur + 0.02);
  }

  function playNoise(opts) {
    const c = ensureContext();
    if (!c || muted || !noiseBuffer) return;
    const now = opts.time ?? c.currentTime;
    const dur = opts.dur ?? 0.08;
    const dest = opts.bus === "music" ? musicGain : sfxGain;

    const src = c.createBufferSource();
    src.buffer = noiseBuffer;

    const filter = c.createBiquadFilter();
    filter.type = opts.filterType || "bandpass";
    filter.frequency.setValueAtTime(opts.filterFreq || 1800, now);
    if (opts.q) filter.Q.setValueAtTime(opts.q, now);

    const gain = c.createGain();
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(opts.vol ?? 0.18, now + 0.005);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);

    src.connect(filter);
    filter.connect(gain);
    gain.connect(dest);

    src.start(now);
    src.stop(now + dur + 0.01);
  }

  // ================= SOUND EFFECTS =================

  /**
   * Bright, golden coin chime with shimmering sparkle harmonic.
   * Escalates gently during quick coin streaks!
   */
  function playCoin(isBonus) {
    const c = ensureContext();
    if (!c || muted) return;
    const now = c.currentTime;
    if (now - lastCoinTime < 0.75) {
      coinComboCount = Math.min(8, coinComboCount + 1);
    } else {
      coinComboCount = 0;
    }
    lastCoinTime = now;

    const semiShift = isBonus ? 5 : Math.min(7, coinComboCount);
    const f1 = midiToFreq(76 + semiShift); // E5+
    const f2 = midiToFreq(83 + semiShift); // B5+
    const f3 = midiToFreq(88 + semiShift); // E6+ sparkle

    playTone({ freq: f1, type: "triangle", vol: 0.34, dur: 0.09, time: now });
    playTone({ freq: f2, type: "sine", vol: 0.38, dur: 0.22, time: now + 0.055 });
    playTone({ freq: f2 * 2, type: "sine", vol: 0.14, dur: 0.18, time: now + 0.065 });
    playTone({ freq: f3, type: "sine", vol: 0.18, dur: 0.18, time: now + 0.11 });
  }

  /**
   * Energetic, punchy rabbit jump!
   */
  function playJump(isSpring) {
    const c = ensureContext();
    if (!c || muted) return;
    const now = c.currentTime;
    if (isSpring) {
      playTone({ freq: 290, freqEnd: 860, type: "triangle", vol: 0.4, dur: 0.24, time: now });
      playTone({ freq: 580, freqEnd: 1240, type: "sine", vol: 0.24, dur: 0.22, time: now + 0.03 });
    } else {
      playTone({ freq: 240, freqEnd: 590, type: "triangle", vol: 0.36, dur: 0.14, time: now });
      playTone({ freq: 420, freqEnd: 740, type: "sine", vol: 0.2, dur: 0.11, time: now + 0.015 });
      playNoise({ filterType: "highpass", filterFreq: 2200, vol: 0.09, dur: 0.05, time: now });
    }
  }

  /**
   * Clear, crisp landing thump.
   */
  function playLand(intensity) {
    const c = ensureContext();
    if (!c || muted) return;
    const now = c.currentTime;
    const scale = Math.max(0.45, Math.min(1.15, intensity || 0.8));
    playTone({ freq: 185, freqEnd: 82, type: "sine", vol: 0.28 * scale, dur: 0.085, time: now });
    playNoise({ filterType: "lowpass", filterFreq: 950, vol: 0.14 * scale, dur: 0.06, time: now });
  }

  /**
   * Subtle, crisp running footstep synced to stride.
   */
  function playStep() {
    const c = ensureContext();
    if (!c || muted) return;
    const now = c.currentTime;
    const jitter = 0.92 + Math.random() * 0.16;
    playTone({ freq: 195 * jitter, freqEnd: 115, type: "triangle", vol: 0.085, dur: 0.038, time: now });
    playNoise({ filterType: "bandpass", filterFreq: 1400 * jitter, q: 1.5, vol: 0.055, dur: 0.032, time: now });
  }

  /**
   * Bouncing off an enemy's head.
   */
  function playEnemyStomp() {
    const c = ensureContext();
    if (!c || muted) return;
    const now = c.currentTime;
    playTone({ freq: 310, freqEnd: 140, type: "sawtooth", filterFreq: 1100, vol: 0.28, dur: 0.09, time: now });
    playTone({ freq: 460, freqEnd: 820, type: "triangle", vol: 0.34, dur: 0.15, time: now + 0.04 });
  }

  /**
   * Powerful impact sound when hitting an enemy or hazard.
   */
  function playHurt(shieldBlocked) {
    const c = ensureContext();
    if (!c || muted) return;
    const now = c.currentTime;
    if (shieldBlocked) {
      // Crystal shield shatter
      playTone({ freq: 880, freqEnd: 330, type: "triangle", vol: 0.34, dur: 0.22, time: now });
      playTone({ freq: 1320, freqEnd: 520, type: "sine", vol: 0.22, dur: 0.18, time: now + 0.03 });
      playNoise({ filterType: "highpass", filterFreq: 2600, vol: 0.24, dur: 0.14, time: now });
    } else {
      playTone({ freq: 240, freqEnd: 78, type: "sawtooth", filterFreq: 950, vol: 0.42, dur: 0.26, time: now });
      playTone({ freq: 180, freqEnd: 68, type: "square", filterFreq: 700, vol: 0.24, dur: 0.24, time: now + 0.02 });
      playNoise({ filterType: "lowpass", filterFreq: 1100, vol: 0.28, dur: 0.16, time: now });
    }
  }

  /**
   * Magical power-up sounds unique per power-up type.
   */
  function playPowerUp(kind) {
    const c = ensureContext();
    if (!c || muted) return;
    const now = c.currentTime;
    if (kind === "speed") {
      // Turbo rising arpeggio
      [64, 68, 71, 76, 80].forEach((m, idx) => {
        playTone({ freq: midiToFreq(m), type: "sawtooth", filterFreq: 2600, vol: 0.22, dur: 0.14, time: now + idx * 0.045 });
      });
    } else if (kind === "shield") {
      // Shimmering protective crystal chord
      [67, 71, 74, 79].forEach((m, idx) => {
        playTone({ freq: midiToFreq(m), type: "sine", vol: 0.24, dur: 0.34, time: now + idx * 0.04 });
      });
      playTone({ freq: midiToFreq(86), type: "triangle", vol: 0.18, dur: 0.32, time: now + 0.14 });
    } else {
      // Special coin bonus jackpot
      [72, 76, 79, 84, 88, 91].forEach((m, idx) => {
        playTone({ freq: midiToFreq(m), type: "triangle", vol: 0.26, dur: 0.18, time: now + idx * 0.048 });
      });
    }
  }

  function playCheckpoint() {
    const c = ensureContext();
    if (!c || muted) return;
    const now = c.currentTime;
    [67, 71, 74, 79].forEach((m, idx) => {
      playTone({ freq: midiToFreq(m), type: "triangle", vol: 0.26, dur: 0.22, time: now + idx * 0.065 });
    });
  }

  function playUiClick() {
    const c = ensureContext();
    if (!c || muted) return;
    playTone({ freq: 620, freqEnd: 780, type: "sine", vol: 0.18, dur: 0.055 });
  }

  /**
   * Joyful original victory fanfare on completing a level.
   */
  function playLevelComplete() {
    const c = ensureContext();
    if (!c || muted) return;
    const now = c.currentTime;
    const fanfare = [
      { m: 72, t: 0.0, d: 0.14 },
      { m: 76, t: 0.11, d: 0.14 },
      { m: 79, t: 0.22, d: 0.14 },
      { m: 84, t: 0.34, d: 0.28 },
      { m: 79, t: 0.56, d: 0.14 },
      { m: 84, t: 0.68, d: 0.55 }
    ];
    fanfare.forEach((n) => {
      playTone({ freq: midiToFreq(n.m), type: "triangle", vol: 0.32, dur: n.d, time: now + n.t });
      playTone({ freq: midiToFreq(n.m - 12), type: "sine", vol: 0.2, dur: n.d, time: now + n.t });
    });
    // Sparkle harmony chord
    [72, 76, 79, 84].forEach((m) => {
      playTone({ freq: midiToFreq(m), type: "sine", vol: 0.16, dur: 0.6, time: now + 0.68 });
    });
  }

  /**
   * Dramatic original game-over cadence.
   */
  function playGameOver() {
    const c = ensureContext();
    if (!c || muted) return;
    const now = c.currentTime;
    const notes = [
      { m: 69, t: 0.0, d: 0.24 },
      { m: 67, t: 0.22, d: 0.24 },
      { m: 65, t: 0.44, d: 0.26 },
      { m: 64, t: 0.68, d: 0.52 }
    ];
    notes.forEach((n) => {
      playTone({ freq: midiToFreq(n.m), type: "triangle", vol: 0.32, dur: n.d, time: now + n.t });
      playTone({ freq: midiToFreq(n.m - 12), type: "sawtooth", filterFreq: 680, vol: 0.16, dur: n.d, time: now + n.t });
    });
  }

  // ================= ORIGINAL BACKGROUND MUSIC SEQUENCER =================

  // 100% original 16-step adventure patterns per level theme
  const MUSIC_TRACKS = {
    1: {
      // Forest Meadow: bright, bouncy C major / F / G adventure
      stepMs: 155,
      lead: [72, 0, 76, 79, 76, 0, 74, 72, 74, 0, 79, 76, 74, 72, 71, 0,
             72, 0, 76, 79, 84, 0, 83, 81, 79, 0, 76, 74, 72, 0, 0, 0],
      bass: [48, 0, 55, 0, 48, 0, 55, 0, 53, 0, 57, 0, 55, 0, 43, 0,
             48, 0, 55, 0, 57, 0, 53, 0, 55, 0, 43, 0, 48, 0, 48, 0]
    },
    2: {
      // Mountain Adventure: heroic Dorian/Mixolydian climb in D
      stepMs: 145,
      lead: [74, 0, 78, 81, 86, 0, 83, 81, 78, 79, 81, 0, 76, 0, 74, 0,
             74, 0, 78, 81, 86, 84, 83, 81, 79, 0, 81, 83, 86, 0, 0, 0],
      bass: [50, 0, 57, 0, 50, 0, 57, 0, 55, 0, 50, 0, 52, 0, 57, 0,
             50, 0, 57, 0, 55, 0, 57, 0, 55, 0, 57, 0, 50, 0, 50, 0]
    },
    3: {
      // Underground Crystal Cave: mysterious, energetic A minor groove
      stepMs: 140,
      lead: [69, 72, 76, 0, 79, 76, 72, 0, 74, 72, 71, 69, 68, 0, 71, 0,
             69, 72, 76, 81, 80, 0, 79, 76, 74, 0, 76, 74, 72, 71, 69, 0],
      bass: [45, 0, 52, 0, 45, 0, 52, 0, 50, 0, 48, 0, 47, 0, 52, 0,
             45, 0, 52, 0, 53, 0, 52, 0, 50, 0, 52, 0, 45, 0, 45, 0]
    }
  };

  function tickMusic() {
    if (!isMusicPlaying || muted || !ctx || ctx.state !== "running") return;
    const track = MUSIC_TRACKS[currentTheme] || MUSIC_TRACKS[1];
    const idx = musicStep % track.lead.length;
    const now = ctx.currentTime;

    const leadMidi = track.lead[idx];
    const bassMidi = track.bass[idx];

    if (leadMidi > 0) {
      playTone({
        bus: "music",
        freq: midiToFreq(leadMidi),
        type: currentTheme === 3 ? "sine" : "triangle",
        vol: 0.24,
        dur: (track.stepMs / 1000) * 1.15,
        time: now
      });
      if (currentTheme === 3) {
        // Crystal shimmer overtone
        playTone({
          bus: "music",
          freq: midiToFreq(leadMidi + 12),
          type: "sine",
          vol: 0.08,
          dur: (track.stepMs / 1000) * 0.9,
          time: now
        });
      }
    }

    if (bassMidi > 0) {
      playTone({
        bus: "music",
        freq: midiToFreq(bassMidi),
        type: "triangle",
        filterFreq: 680,
        vol: 0.34,
        dur: (track.stepMs / 1000) * 1.25,
        time: now
      });
    }

    // Light crisp percussive groove
    if (idx % 4 === 0) {
      playTone({
        bus: "music",
        freq: 165,
        freqEnd: 75,
        type: "sine",
        vol: 0.22,
        dur: 0.07,
        time: now
      });
    } else if (idx % 4 === 2) {
      playNoise({
        bus: "music",
        filterType: "highpass",
        filterFreq: 3400,
        vol: 0.07,
        dur: 0.04,
        time: now
      });
    } else if (idx % 2 === 1) {
      playNoise({
        bus: "music",
        filterType: "highpass",
        filterFreq: 5200,
        vol: 0.035,
        dur: 0.025,
        time: now
      });
    }

    musicStep++;
  }

  function startMusic(themeId) {
    ensureContext();
    currentTheme = themeId || 1;
    if (isMusicPlaying) {
      stopMusic();
    }
    const track = MUSIC_TRACKS[currentTheme] || MUSIC_TRACKS[1];
    isMusicPlaying = true;
    musicStep = 0;
    tickMusic();
    musicTimer = window.setInterval(tickMusic, track.stepMs);
  }

  function stopMusic() {
    isMusicPlaying = false;
    if (musicTimer !== null) {
      window.clearInterval(musicTimer);
      musicTimer = null;
    }
  }

  function pauseMusic() {
    if (musicTimer !== null) {
      window.clearInterval(musicTimer);
      musicTimer = null;
    }
  }

  function resumeMusic() {
    if (!isMusicPlaying) return;
    if (musicTimer === null) {
      const track = MUSIC_TRACKS[currentTheme] || MUSIC_TRACKS[1];
      musicTimer = window.setInterval(tickMusic, track.stepMs);
    }
  }

  return {
    unlock,
    setVolumes,
    playCoin,
    playJump,
    playLand,
    playStep,
    playEnemyStomp,
    playHurt,
    playPowerUp,
    playCheckpoint,
    playUiClick,
    playLevelComplete,
    playGameOver,
    startMusic,
    stopMusic,
    pauseMusic,
    resumeMusic
  };
})();
