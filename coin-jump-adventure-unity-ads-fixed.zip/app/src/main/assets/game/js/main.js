/**
 * UI controller, input bindings (touch + keyboard), Start mascot animation,
 * Settings persistence, and Android WebView lifecycle integration.
 */
window.addEventListener("DOMContentLoaded", function () {
  const canvas = document.getElementById("gameCanvas");
  const mascotCanvas = document.getElementById("mascotCanvas");

  // Screens & HUD
  const hud = document.getElementById("hud");
  const touchControls = document.getElementById("touchControls");
  const startScreen = document.getElementById("startScreen");
  const levelSelectScreen = document.getElementById("levelSelectScreen");
  const pauseScreen = document.getElementById("pauseScreen");
  const settingsScreen = document.getElementById("settingsScreen");
  const levelCompleteScreen = document.getElementById("levelCompleteScreen");
  const gameOverScreen = document.getElementById("gameOverScreen");

  // HUD elements
  const livesIcons = document.getElementById("livesIcons");
  const coinCount = document.getElementById("coinCount");
  const coinTotal = document.getElementById("coinTotal");
  const scoreValue = document.getElementById("scoreValue");
  const levelBanner = document.getElementById("levelBanner");
  const powerupBar = document.getElementById("powerupBar");
  const hudMuteIcon = document.getElementById("hudMuteIcon");
  const toastBanner = document.getElementById("toastBanner");

  // Menu stats
  const menuBestScore = document.getElementById("menuBestScore");
  const menuTotalCoins = document.getElementById("menuTotalCoins");
  const menuTotalStars = document.getElementById("menuTotalStars");
  const levelGrid = document.getElementById("levelGrid");

  // Settings elements
  const btnMuteToggle = document.getElementById("btnMuteToggle");
  const musicVolumeSlider = document.getElementById("musicVolumeSlider");
  const musicVolumeValue = document.getElementById("musicVolumeValue");
  const sfxVolumeSlider = document.getElementById("sfxVolumeSlider");
  const sfxVolumeValue = document.getElementById("sfxVolumeValue");
  const btnTouchMode = document.getElementById("btnTouchMode");

  let saveData = window.GameStorage.load();
  let settingsReturnScreen = "start";
  let toastTimeout = null;

  function applySettingsToAudioAndUi() {
    const s = saveData.settings;
    window.SoundEngine.setVolumes(s.musicVolume, s.sfxVolume, s.muted);
    hudMuteIcon.textContent = s.muted ? "🔇" : "🔊";

    btnMuteToggle.textContent = s.muted ? "🔇 MUTED" : "🔊 ON";
    btnMuteToggle.classList.toggle("muted", s.muted);

    musicVolumeSlider.value = Math.round(s.musicVolume * 100);
    musicVolumeValue.textContent = `${Math.round(s.musicVolume * 100)}%`;

    sfxVolumeSlider.value = Math.round(s.sfxVolume * 100);
    sfxVolumeValue.textContent = `${Math.round(s.sfxVolume * 100)}%`;

    btnTouchMode.textContent = s.touchMode.toUpperCase();
    updateTouchControlsVisibility(engine ? engine.getMode() : "menu");
  }

  function isTouchEnvironment() {
    return (
      "ontouchstart" in window ||
      navigator.maxTouchPoints > 0 ||
      window.innerWidth <= 960 ||
      Boolean(window.AndroidStorage)
    );
  }

  function updateTouchControlsVisibility(mode) {
    const touchSetting = saveData.settings.touchMode;
    const shouldShow =
      mode === "playing" &&
      (touchSetting === "on" || (touchSetting === "auto" && isTouchEnvironment()));
    touchControls.classList.toggle("hidden", !shouldShow);
  }

  function showToast(msg) {
    toastBanner.textContent = msg;
    toastBanner.classList.remove("hidden");
    if (toastTimeout) window.clearTimeout(toastTimeout);
    toastTimeout = window.setTimeout(() => {
      toastBanner.classList.add("hidden");
    }, 2200);
  }

  function hideAllOverlays() {
    startScreen.classList.add("hidden");
    levelSelectScreen.classList.add("hidden");
    pauseScreen.classList.add("hidden");
    settingsScreen.classList.add("hidden");
    levelCompleteScreen.classList.add("hidden");
    gameOverScreen.classList.add("hidden");
  }

  function refreshMenuStats() {
    saveData = window.GameStorage.load();
    menuBestScore.textContent = saveData.bestScore.toLocaleString();
    menuTotalCoins.textContent = saveData.totalCoins.toLocaleString();
    const totalStars = [1, 2, 3].reduce((sum, id) => sum + (saveData.levels[id]?.stars || 0), 0);
    menuTotalStars.textContent = `${totalStars} / 9`;
  }

  function renderLevelCards() {
    saveData = window.GameStorage.load();
    levelGrid.innerHTML = "";
    const levels = window.GameLevels.getAll();

    levels.forEach((lvl) => {
      const stats = saveData.levels[lvl.id] || { completed: false, stars: 0, bestScore: 0 };
      const starStr = "★".repeat(stats.stars) + "☆".repeat(3 - stats.stars);

      const card = document.createElement("button");
      card.type = "button";
      card.className = `level-card theme-${lvl.theme}`;
      card.innerHTML = `
        <div class="level-top">
          <span class="level-num">Level ${lvl.id}</span>
          <span class="level-diff">${lvl.difficulty}</span>
        </div>
        <h3 class="level-name">${lvl.name}</h3>
        <p class="level-desc">${lvl.subtitle}</p>
        <div class="level-meta">
          <span class="level-stars">${starStr}</span>
          <span>${stats.bestScore > 0 ? "Best: " + stats.bestScore : "Play ▶"}</span>
        </div>
      `;
      card.addEventListener("click", () => {
        window.SoundEngine.unlock();
        window.SoundEngine.playUiClick();
        hideAllOverlays();
        engine.startLevel(lvl.id);
      });
      levelGrid.appendChild(card);
    });
  }

  const engine = window.CoinJumpGame.createEngine(canvas, {
    onModeChange: function (mode) {
      if (mode === "playing") {
        hideAllOverlays();
        hud.classList.remove("hidden");
      } else if (mode === "paused") {
        hud.classList.remove("hidden");
        document.getElementById("pauseLevelName").textContent =
          `Level ${engine.getLevelId()}: ${window.GameLevels.getLevel(engine.getLevelId()).name}`;
        pauseScreen.classList.remove("hidden");
      } else if (mode === "menu") {
        hud.classList.add("hidden");
        hideAllOverlays();
        refreshMenuStats();
        startScreen.classList.remove("hidden");
      }
      updateTouchControlsVisibility(mode);
    },

    onHudUpdate: function (snap) {
      livesIcons.textContent = snap.lives > 0 ? "❤️".repeat(snap.lives) : "🤍";
      coinCount.textContent = String(snap.coins);
      coinTotal.textContent = `/ ${snap.totalCoins}`;
      scoreValue.textContent = snap.score.toLocaleString();
      levelBanner.textContent = `Lv.${snap.levelId} • ${snap.levelName}`;

      const chips = [];
      if (snap.speedTimer > 0) {
        chips.push(`<span class="powerup-chip speed">⚡ ${Math.ceil(snap.speedTimer)}s</span>`);
      }
      if (snap.shieldTimer > 0) {
        chips.push(`<span class="powerup-chip shield">🛡️ ${Math.ceil(snap.shieldTimer)}s</span>`);
      }
      if (snap.magnetTimer > 0) {
        chips.push(`<span class="powerup-chip magnet">🌟 2x ${Math.ceil(snap.magnetTimer)}s</span>`);
      }
      powerupBar.innerHTML = chips.join("");
    },

    onLevelComplete: function (res) {
      updateTouchControlsVisibility("complete");
      document.getElementById("completeTitle").textContent =
        res.levelId === 3 ? "Grand Adventure Cleared!" : `${res.levelName} Cleared!`;
      document.getElementById("completeStars").textContent =
        "★".repeat(res.stars) + "☆".repeat(3 - res.stars);
      document.getElementById("resCoins").textContent = `${res.coins} / ${res.totalCoins}`;
      document.getElementById("resCoinBonus").textContent = `+${res.coinBonus}`;
      document.getElementById("resTimeBonus").textContent = `+${res.timeBonus}`;
      document.getElementById("resTotalScore").textContent = res.totalScore.toLocaleString();
      document.getElementById("newRecordBadge").classList.toggle("hidden", !res.isNewBest);

      const nextBtn = document.getElementById("btnNextLevel");
      nextBtn.textContent = res.hasNextLevel ? "NEXT LEVEL ▶" : "PLAY AGAIN FROM LV.1 ▶";
      levelCompleteScreen.classList.remove("hidden");
    },

    onGameOver: function (res) {
      updateTouchControlsVisibility("gameover");
      if (window.AndroidAds && window.AndroidAds.showInterstitial) {
        window.AndroidAds.showInterstitial();
      }
      document.getElementById("goCoins").textContent = String(res.coins);
      document.getElementById("goScore").textContent = res.score.toLocaleString();
      gameOverScreen.classList.remove("hidden");
    },

    onToast: showToast
  });

  // ================= BUTTON WIRING =================
  document.getElementById("btnPlay").addEventListener("click", () => {
    window.SoundEngine.unlock();
    window.SoundEngine.playUiClick();
    // Resume highest incomplete level or level 1
    saveData = window.GameStorage.load();
    let targetLevel = 1;
    if (saveData.levels[1]?.completed && !saveData.levels[2]?.completed) targetLevel = 2;
    else if (saveData.levels[2]?.completed && !saveData.levels[3]?.completed) targetLevel = 3;
    engine.startLevel(targetLevel);
  });

  document.getElementById("btnLevelSelect").addEventListener("click", () => {
    window.SoundEngine.unlock();
    window.SoundEngine.playUiClick();
    startScreen.classList.add("hidden");
    renderLevelCards();
    levelSelectScreen.classList.remove("hidden");
  });

  document.getElementById("btnCloseLevels").addEventListener("click", () => {
    window.SoundEngine.playUiClick();
    levelSelectScreen.classList.add("hidden");
    startScreen.classList.remove("hidden");
  });

  function openSettings(fromScreen) {
    settingsReturnScreen = fromScreen;
    startScreen.classList.add("hidden");
    pauseScreen.classList.add("hidden");
    settingsScreen.classList.remove("hidden");
  }

  function closeSettings() {
    window.SoundEngine.playUiClick();
    settingsScreen.classList.add("hidden");
    if (settingsReturnScreen === "pause") {
      pauseScreen.classList.remove("hidden");
    } else if (settingsReturnScreen === "hud") {
      engine.resume();
    } else {
      startScreen.classList.remove("hidden");
    }
  }

  document.getElementById("btnStartSettings").addEventListener("click", () => {
    window.SoundEngine.unlock();
    window.SoundEngine.playUiClick();
    openSettings("start");
  });

  document.getElementById("btnPauseSettings").addEventListener("click", () => {
    window.SoundEngine.playUiClick();
    openSettings("pause");
  });

  document.getElementById("hudSettingsBtn").addEventListener("click", () => {
    window.SoundEngine.unlock();
    window.SoundEngine.playUiClick();
    engine.pause();
    openSettings("hud");
  });

  document.getElementById("btnCloseSettings").addEventListener("click", closeSettings);
  document.getElementById("btnSettingsDone").addEventListener("click", closeSettings);

  function toggleMute() {
    window.SoundEngine.unlock();
    saveData.settings = window.GameStorage.updateSettings({ muted: !saveData.settings.muted });
    applySettingsToAudioAndUi();
    if (!saveData.settings.muted) window.SoundEngine.playUiClick();
  }

  btnMuteToggle.addEventListener("click", toggleMute);
  document.getElementById("hudMuteBtn").addEventListener("click", toggleMute);

  musicVolumeSlider.addEventListener("input", (e) => {
    window.SoundEngine.unlock();
    const val = Number(e.target.value) / 100;
    saveData.settings = window.GameStorage.updateSettings({ musicVolume: val, muted: false });
    applySettingsToAudioAndUi();
  });

  sfxVolumeSlider.addEventListener("input", (e) => {
    window.SoundEngine.unlock();
    const val = Number(e.target.value) / 100;
    saveData.settings = window.GameStorage.updateSettings({ sfxVolume: val, muted: false });
    applySettingsToAudioAndUi();
  });

  sfxVolumeSlider.addEventListener("change", () => {
    window.SoundEngine.playCoin(false);
  });

  btnTouchMode.addEventListener("click", () => {
    window.SoundEngine.playUiClick();
    const order = ["auto", "on", "off"];
    const next = order[(order.indexOf(saveData.settings.touchMode) + 1) % order.length];
    saveData.settings = window.GameStorage.updateSettings({ touchMode: next });
    applySettingsToAudioAndUi();
  });

  // Pause / Resume / Restart
  document.getElementById("hudPauseBtn").addEventListener("click", () => {
    window.SoundEngine.playUiClick();
    engine.pause();
  });
  document.getElementById("hudRestartBtn").addEventListener("click", () => {
    window.SoundEngine.unlock();
    window.SoundEngine.playUiClick();
    engine.restart();
  });
  document.getElementById("btnResume").addEventListener("click", () => {
    window.SoundEngine.playUiClick();
    engine.resume();
  });
  document.getElementById("btnPauseRestart").addEventListener("click", () => {
    window.SoundEngine.playUiClick();
    engine.restart();
  });
  document.getElementById("btnPauseLevels").addEventListener("click", () => {
    window.SoundEngine.playUiClick();
    engine.stopToMenu();
    startScreen.classList.add("hidden");
    renderLevelCards();
    levelSelectScreen.classList.remove("hidden");
  });
  document.getElementById("btnPauseMenu").addEventListener("click", () => {
    window.SoundEngine.playUiClick();
    engine.stopToMenu();
  });

  // Level Complete & Game Over
  document.getElementById("btnNextLevel").addEventListener("click", () => {
    window.SoundEngine.playUiClick();
    const nextId = engine.getLevelId() < 3 ? engine.getLevelId() + 1 : 1;
    engine.startLevel(nextId);
  });
  document.getElementById("btnReplayLevel").addEventListener("click", () => {
    window.SoundEngine.playUiClick();
    engine.restart();
  });
  document.getElementById("btnCompleteLevels").addEventListener("click", () => {
    window.SoundEngine.playUiClick();
    engine.stopToMenu();
    startScreen.classList.add("hidden");
    renderLevelCards();
    levelSelectScreen.classList.remove("hidden");
  });

  document.getElementById("btnRewardLife").addEventListener("click", () => {
    window.SoundEngine.playUiClick();
    if (window.AndroidAds && window.AndroidAds.showRewarded) {
      window.AndroidAds.showRewarded();
    } else {
      showToast("Rewarded ads are not available right now.");
    }
  });

  document.getElementById("btnTryAgain").addEventListener("click", () => {
    window.SoundEngine.playUiClick();
    engine.restart();
  });
  document.getElementById("btnGoLevels").addEventListener("click", () => {
    window.SoundEngine.playUiClick();
    engine.stopToMenu();
    startScreen.classList.add("hidden");
    renderLevelCards();
    levelSelectScreen.classList.remove("hidden");
  });
  document.getElementById("btnGoMenu").addEventListener("click", () => {
    window.SoundEngine.playUiClick();
    engine.stopToMenu();
  });

  // ================= TOUCH CONTROLS (MULTI-TOUCH POINTER EVENTS) =================
  function bindTouchButton(el, action) {
    const activePointers = new Set();

    function release(e) {
      if (e && activePointers.has(e.pointerId)) {
        activePointers.delete(e.pointerId);
      }
      if (activePointers.size === 0) {
        el.classList.remove("active");
        engine.setInput(action, false);
      }
    }

    el.addEventListener("pointerdown", (e) => {
      e.preventDefault();
      window.SoundEngine.unlock();
      activePointers.add(e.pointerId);
      try {
        el.setPointerCapture(e.pointerId);
      } catch (_) {}
      el.classList.add("active");
      engine.setInput(action, true);
    });

    el.addEventListener("pointerup", release);
    el.addEventListener("pointercancel", release);
    el.addEventListener("lostpointercapture", release);
  }

  bindTouchButton(document.getElementById("btnLeft"), "left");
  bindTouchButton(document.getElementById("btnRight"), "right");
  bindTouchButton(document.getElementById("btnJump"), "jump");

  // ================= KEYBOARD CONTROLS =================
  window.addEventListener("keydown", (e) => {
    if (["ArrowLeft", "ArrowRight", "ArrowUp", "Space"].includes(e.code)) {
      e.preventDefault();
    }
    window.SoundEngine.unlock();

    if (e.code === "ArrowLeft" || e.code === "KeyA") engine.setInput("left", true);
    if (e.code === "ArrowRight" || e.code === "KeyD") engine.setInput("right", true);
    if (e.code === "Space" || e.code === "ArrowUp" || e.code === "KeyW") engine.setInput("jump", true);

    if (e.code === "KeyP" || e.code === "Escape") {
      if (engine.getMode() === "playing") engine.pause();
      else if (engine.getMode() === "paused") engine.resume();
    }
    if (e.code === "KeyR" && (engine.getMode() === "playing" || engine.getMode() === "paused")) {
      engine.restart();
    }
  });

  window.addEventListener("keyup", (e) => {
    if (e.code === "ArrowLeft" || e.code === "KeyA") engine.setInput("left", false);
    if (e.code === "ArrowRight" || e.code === "KeyD") engine.setInput("right", false);
    if (e.code === "Space" || e.code === "ArrowUp" || e.code === "KeyW") engine.setInput("jump", false);
  });

  // ================= MASCOT PREVIEW ANIMATION =================
  const mCtx = mascotCanvas.getContext("2d");
  let mascotTime = 0;
  function animateMascot() {
    mascotTime += 0.016;
    mCtx.clearRect(0, 0, mascotCanvas.width, mascotCanvas.height);

    // Floating gold coin beside Pip
    const coinY = 58 + Math.sin(mascotTime * 3.5) * 6;
    const spin = 0.4 + 0.6 * Math.abs(Math.cos(mascotTime * 3.2));
    mCtx.save();
    mCtx.translate(132, coinY);
    mCtx.fillStyle = "rgba(253, 224, 71, 0.25)";
    mCtx.beginPath();
    mCtx.arc(0, 0, 24, 0, Math.PI * 2);
    mCtx.fill();
    mCtx.scale(spin, 1);
    mCtx.fillStyle = "#f59e0b";
    mCtx.beginPath();
    mCtx.arc(0, 0, 16, 0, Math.PI * 2);
    mCtx.fill();
    mCtx.fillStyle = "#fde047";
    mCtx.beginPath();
    mCtx.arc(0, 0, 12.5, 0, Math.PI * 2);
    mCtx.fill();
    mCtx.fillStyle = "#b45309";
    mCtx.fillRect(-2.5, -6, 5, 12);
    mCtx.restore();

    // Cheerful hopping rabbit
    const hop = Math.abs(Math.sin(mascotTime * 3)) * 14;
    mCtx.save();
    mCtx.translate(68, 128 - hop);
    mCtx.scale(1.65, 1.65);
    window.GameRenderer.drawRabbit(mCtx, {
      x: 0,
      y: 0,
      facing: 1,
      grounded: hop < 2,
      vx: 140,
      vy: -hop * 12,
      runCycle: mascotTime * 5,
      isBlinking: Math.sin(mascotTime * 1.3) > 0.96,
      hasShield: false,
      hasSpeed: false,
      time: mascotTime
    });
    mCtx.restore();

    if (!startScreen.classList.contains("hidden")) {
      window.requestAnimationFrame(animateMascot);
    } else {
      window.setTimeout(() => window.requestAnimationFrame(animateMascot), 250);
    }
  }

  // Android lifecycle & hardware back button integration
  window.CoinJumpApp = {
    grantExtraLife: function () {
      const granted = engine.grantExtraLife();
      if (!granted) showToast("Extra life is not available now.");
      return granted;
    },
    onRewardAdUnavailable: function () { showToast("Ad not ready. Please try again shortly."); },
    onAppPause: function () {
      if (engine.getMode() === "playing") {
        engine.pause();
      } else {
        window.SoundEngine.pauseMusic();
      }
    },
    onAppResume: function () {
      if (engine.getMode() === "playing") {
        window.SoundEngine.resumeMusic();
      }
    },
    handleBack: function () {
      if (!settingsScreen.classList.contains("hidden")) {
        closeSettings();
        return "handled";
      }
      if (!levelSelectScreen.classList.contains("hidden")) {
        levelSelectScreen.classList.add("hidden");
        startScreen.classList.remove("hidden");
        return "handled";
      }
      if (engine.getMode() === "playing") {
        engine.pause();
        return "handled";
      }
      if (engine.getMode() === "paused" || engine.getMode() === "complete" || engine.getMode() === "gameover") {
        engine.stopToMenu();
        return "handled";
      }
      return "exit";
    }
  };

  // Initialize!
  applySettingsToAudioAndUi();
  refreshMenuStats();
  engine.init();
  animateMascot();
});
