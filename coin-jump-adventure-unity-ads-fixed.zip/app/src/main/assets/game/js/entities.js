/**
 * Game entity factories and physics helpers for Coin Jump Adventure.
 */
window.GameEntities = (function () {
  const GRAVITY = 1650;
  const JUMP_VEL = -650;
  const SPRING_VEL = -885;
  const BASE_SPEED = 278;
  const BOOST_SPEED = 390;

  function createPlayer(spawn) {
    return {
      x: spawn.x,
      y: spawn.y,
      w: 34,
      h: 46,
      vx: 0,
      vy: 0,
      facing: 1,
      grounded: false,
      onPlatform: null,
      coyoteTimer: 0,
      jumpBuffer: 0,
      invulnTimer: 0,
      speedTimer: 0,
      shieldTimer: 0,
      magnetTimer: 0,
      runCycle: 0,
      stepAccum: 0,
      squashX: 1,
      squashY: 1,
      blinkTimer: 2.5,
      isBlinking: false,
      trailTimer: 0,
      trail: []
    };
  }

  function buildWorld(levelDef) {
    const platforms = levelDef.platforms.map((p) => Object.assign({ dx: 0, dy: 0 }, p));
    const movingPlatforms = (levelDef.movingPlatforms || []).map((mp) => ({
      x: mp.x,
      y: mp.y,
      baseX: mp.x,
      baseY: mp.y,
      w: mp.w,
      h: mp.h,
      axis: mp.axis,
      range: mp.range,
      speed: mp.speed,
      style: mp.style,
      phase: 0,
      dx: 0,
      dy: 0
    }));

    const coins = (levelDef.coins || []).map((c, idx) => ({
      x: c.x,
      y: c.y,
      r: 13,
      collected: false,
      phase: idx * 0.45
    }));

    const powerups = (levelDef.powerups || []).map((pu, idx) => ({
      type: pu.type,
      x: pu.x,
      y: pu.y,
      baseY: pu.y,
      r: 17,
      collected: false,
      phase: idx * 1.1
    }));

    const enemies = (levelDef.enemies || []).map((e) => ({
      type: e.type,
      x: e.x,
      y: e.y,
      baseY: e.y,
      w: e.type === "bat" ? 36 : 34,
      h: e.type === "bat" ? 28 : 28,
      minX: e.minX || e.x - 60,
      maxX: e.maxX || e.x + 60,
      minY: e.minY || e.y - 45,
      maxY: e.maxY || e.y + 45,
      rangeX: e.rangeX || 45,
      speed: e.speed || 90,
      dir: 1,
      phase: Math.random() * Math.PI * 2,
      alive: true,
      squishTimer: 0
    }));

    const checkpoints = (levelDef.checkpoints || []).map((cp) => ({
      x: cp.x,
      y: cp.y,
      activated: false,
      glow: 0
    }));

    const springs = (levelDef.springs || []).map((sp) => ({
      x: sp.x,
      y: sp.y,
      w: 38,
      h: 18,
      bounceAnim: 0
    }));

    const hazards = (levelDef.hazards || []).map((hz) => ({
      x: hz.x,
      y: hz.y,
      w: hz.w,
      h: 18,
      kind: hz.kind
    }));

    return {
      platforms,
      movingPlatforms,
      coins,
      powerups,
      enemies,
      checkpoints,
      springs,
      hazards,
      particles: [],
      floatingTexts: []
    };
  }

  function spawnParticles(world, x, y, color, count, speed, gravityScale) {
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + Math.random() * 0.6;
      const mag = (0.4 + Math.random() * 0.7) * (speed || 180);
      world.particles.push({
        x,
        y,
        vx: Math.cos(angle) * mag,
        vy: Math.sin(angle) * mag - 40,
        r: 2.5 + Math.random() * 3.5,
        color,
        life: 0.35 + Math.random() * 0.35,
        maxLife: 0.7,
        g: gravityScale === undefined ? 450 : gravityScale * 450
      });
    }
  }

  function spawnSparkles(world, x, y, color, count) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const mag = 60 + Math.random() * 140;
      world.particles.push({
        x,
        y,
        vx: Math.cos(angle) * mag,
        vy: Math.sin(angle) * mag - 30,
        r: 3 + Math.random() * 3,
        color,
        star: true,
        life: 0.4 + Math.random() * 0.3,
        maxLife: 0.7,
        g: 160
      });
    }
  }

  function spawnFloatingText(world, x, y, text, color) {
    world.floatingTexts.push({
      x,
      y,
      text,
      color: color || "#ffd447",
      life: 0.85,
      maxLife: 0.85
    });
  }

  return {
    GRAVITY,
    JUMP_VEL,
    SPRING_VEL,
    BASE_SPEED,
    BOOST_SPEED,
    createPlayer,
    buildWorld,
    spawnParticles,
    spawnSparkles,
    spawnFloatingText
  };
})();
