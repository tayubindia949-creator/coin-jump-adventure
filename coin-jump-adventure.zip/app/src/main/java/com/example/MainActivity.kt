package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
    )
    setContent {
      MyApplicationTheme {
        CoinJumpGameScreen(onExitApp = { finish() })
      }
    }
  }
}

private class AndroidStorageBridge(context: Context) {
  private val prefs = context.getSharedPreferences("coin_jump_adventure_prefs", Context.MODE_PRIVATE)

  @JavascriptInterface
  fun getItem(key: String): String? = prefs.getString(key, null)

  @JavascriptInterface
  fun setItem(key: String, value: String) {
    prefs.edit().putString(key, value).apply()
  }

  @JavascriptInterface
  fun removeItem(key: String) {
    prefs.edit().remove(key).apply()
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun CoinJumpGameScreen(onExitApp: () -> Unit) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val density = LocalDensity.current
  val layoutDirection = LocalLayoutDirection.current

  val safeInsets = WindowInsets.safeDrawing
  val topDp = with(density) { safeInsets.getTop(density).toDp().value }
  val bottomDp = with(density) { safeInsets.getBottom(density).toDp().value }
  val leftDp = with(density) { safeInsets.getLeft(density, layoutDirection).toDp().value }
  val rightDp = with(density) { safeInsets.getRight(density, layoutDirection).toDp().value }

  var pageLoaded by remember { mutableStateOf(false) }

  val webView = remember {
    WebView(context).apply {
      layoutParams =
        ViewGroup.LayoutParams(
          ViewGroup.LayoutParams.MATCH_PARENT,
          ViewGroup.LayoutParams.MATCH_PARENT,
        )
      setBackgroundColor(AndroidColor.rgb(15, 42, 32))
      setLayerType(View.LAYER_TYPE_HARDWARE, null)
      isFocusable = true
      isFocusableInTouchMode = true
      overScrollMode = View.OVER_SCROLL_NEVER

      settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        databaseEnabled = true
        allowFileAccess = true
        @Suppress("DEPRECATION")
        allowFileAccessFromFileURLs = true
        mediaPlaybackRequiresUserGesture = false
        useWideViewPort = true
        loadWithOverviewMode = true
        setSupportZoom(false)
        builtInZoomControls = false
        displayZoomControls = false
        cacheMode = WebSettings.LOAD_DEFAULT
      }

      addJavascriptInterface(AndroidStorageBridge(context.applicationContext), "AndroidStorage")
      webChromeClient = WebChromeClient()
      webViewClient =
        object : WebViewClient() {
          override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            pageLoaded = true
          }
        }
      loadUrl("file:///android_asset/game/index.html")
    }
  }

  LaunchedEffect(pageLoaded, topDp, bottomDp, leftDp, rightDp) {
    if (pageLoaded) {
      val js =
        """
        (function() {
          var r = document.documentElement.style;
          r.setProperty('--safe-top', '${topDp}px');
          r.setProperty('--safe-bottom', '${bottomDp}px');
          r.setProperty('--safe-left', '${leftDp}px');
          r.setProperty('--safe-right', '${rightDp}px');
        })();
        """.trimIndent()
      webView.evaluateJavascript(js, null)
    }
  }

  DisposableEffect(lifecycleOwner, webView) {
    val observer = LifecycleEventObserver { _, event ->
      when (event) {
        Lifecycle.Event.ON_PAUSE -> {
          webView.evaluateJavascript(
            "window.CoinJumpApp && window.CoinJumpApp.onAppPause && window.CoinJumpApp.onAppPause();",
            null,
          )
          webView.onPause()
        }
        Lifecycle.Event.ON_RESUME -> {
          webView.onResume()
          webView.evaluateJavascript(
            "window.CoinJumpApp && window.CoinJumpApp.onAppResume && window.CoinJumpApp.onAppResume();",
            null,
          )
        }
        Lifecycle.Event.ON_DESTROY -> {
          webView.destroy()
        }
        else -> Unit
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  BackHandler {
    webView.evaluateJavascript(
      "(function(){ return window.CoinJumpApp && window.CoinJumpApp.handleBack ? window.CoinJumpApp.handleBack() : 'exit'; })();",
    ) { result ->
      if (result?.contains("exit") == true) {
        onExitApp()
      }
    }
  }

  Box(modifier = Modifier.fillMaxSize().background(Color(0xFF0F2A20))) {
    AndroidView(factory = { webView }, modifier = Modifier.fillMaxSize())
  }
}
